# Changelog

All notable changes to NEXUS are documented here.
Format follows [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).
Versioning follows [Semantic Versioning](https://semver.org/).

---

## [5.1.0] — 2026-05-03

### Added
- **Real-time Binance WebSocket** — BTC/USDT and ETH/USDT stream live ticks directly into the ticker strip and sparklines
- **Yahoo Finance v8 integration** — AAPL, NVDA, SPY, QQQ, GOLD (GC=F), EUR/USD fetched on load and refreshed every 90 seconds with real close prices and 5-day history
- **Data Source Badges** — `● LIVE`, `◌ SIM`, `⚠ STALE` badges on every ticker tile and portfolio position
- **Data Status Panel** — header shows `LIVE / PARTIAL / OFFLINE` with per-ticker dot grid
- **Mercury MCP tab** — dedicated tab to load live Mercury bank account balances and recent transactions
- **Live price injection** — Agent chat and RAG retrieval automatically include all 8 live prices in every Claude API call
- **WebSocket auto-reconnect** — 3-second backoff reconnect on close, error→close chain
- **AbortSignal timeout** — 6-second timeout on all Yahoo Finance fetch requests

### Changed
- Monte Carlo simulation now seeds from the real live market price instead of fallback
- Portfolio P&L now recomputes against live fetched prices in real time
- RAG engine query now prepends live market prices to every retrieval prompt

### Fixed
- Graceful per-ticker fallback to Gaussian simulation if any live feed fails
- Stable Yahoo Finance polling interval — clears on unmount to prevent memory leaks

---

## [5.0.0] — 2026-04-28

### Added
- **Quantum-enhanced Monte Carlo** — 500-path 30-day price simulation with xorshift32 + cosine phase quantum entropy (15/85 blend with Gaussian GBM)
- **Full SVG Monte Carlo chart** — P05/P25/P50/P75/P95 percentile bands, 80 sample paths rendered, VaR/CVaR metrics, quantum coherence score
- **Global Live News Panel** — 12 financial headlines across MACRO/CRYPTO/EQUITY/FOREX/COMMOD/QUANT with POS/NEG/NEU sentiment scoring and category filter
- **Secure Withdrawal System** — 4-step flow: Amount → Review → 2FA PIN → Confirmation
- **Withdrawal history** — persistent ledger with masked wallet addresses
- **Withdrawal validation** — amount bounds check, address format validation, NaN injection prevention

### Security (v5.0 audit)
- `sanitize()` — strips `< > " ' \` \\`, trims, caps at 500 chars — applied to all user inputs
- `sanitizeNum()` — rejects NaN, Infinity, negative values on all financial amounts
- `checkRL()` — client-side rate limiter, 10 Claude API calls per 60-second window
- `maskAddr()` — wallet addresses always shown as `XXXXXX...XXXX` in UI and history
- Withdrawal amount bounded to available cash (cannot overdraw)
- All buttons disabled during loading states (prevents duplicate API calls)

### Fixed
- **P&L formula** — corrected to `(currentPrice − entryPrice) × size` (was computing incorrectly)
- **Price simulation** — replaced broken ratio tracking with proper Box-Muller Gaussian drift
- **Ticker change%** — now correctly tracks deviation from stable base price (not prev tick)
- **SVG gradient IDs** — now deterministic and collision-free across multiple sparklines
- **useEffect dependencies** — all dependency arrays fully declared, no stale closure bugs
- **Chat auto-scroll** — `scrollIntoView` ref now correctly tracks new messages

---

## [4.2.0] — 2026-04-15 *(Initial Release)*

### Added
- 5 AI trading agents: ALPHA, OMEGA, SIGMA, DELTA, ZETA with per-agent chat
- Consensus voting engine — 5-agent BUY/SELL/HOLD per ticker with visual breakdown
- Vectorless RAG engine — semantic document retrieval via Claude, no vector DB
- Cybersecurity suite — live threat feed, security score gauge, encryption status panel
- Portfolio tracker — positions, P&L, Sharpe ratio, VaR, drawdown
- System event log with live feed
- Gaussian price simulation with sparklines (pre-live-data)
- 8-tab navigation: Dashboard, Agents, Monte Carlo, RAG, Cyber, Portfolio, Mercury, Withdraw

---

[5.1.0]: https://github.com/YOUR_USERNAME/nexus-trading-system/compare/v5.0.0...v5.1.0
[5.0.0]: https://github.com/YOUR_USERNAME/nexus-trading-system/compare/v4.2.0...v5.0.0
[4.2.0]: https://github.com/YOUR_USERNAME/nexus-trading-system/releases/tag/v4.2.0
