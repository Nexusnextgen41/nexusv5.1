#!/bin/bash
# ─────────────────────────────────────────────────────────────────
# NEXUS v5.1 — GitHub Launch Script
# Run this after cloning to set up and publish your repo
# Usage: chmod +x launch.sh && ./launch.sh
# ─────────────────────────────────────────────────────────────────

set -e

GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo ""
echo -e "${CYAN}◈ NEXUS v5.1 — GitHub Launch Script${NC}"
echo "────────────────────────────────────────"
echo ""

# 1. Check prerequisites
echo -e "${YELLOW}[1/6]${NC} Checking prerequisites..."
command -v node >/dev/null 2>&1 || { echo -e "${RED}✗ Node.js not found. Install from https://nodejs.org${NC}"; exit 1; }
command -v npm  >/dev/null 2>&1 || { echo -e "${RED}✗ npm not found.${NC}"; exit 1; }
command -v git  >/dev/null 2>&1 || { echo -e "${RED}✗ git not found.${NC}"; exit 1; }
NODE_VER=$(node -v | cut -d. -f1 | tr -d 'v')
if [ "$NODE_VER" -lt 18 ]; then echo -e "${RED}✗ Node 18+ required (found $(node -v))${NC}"; exit 1; fi
echo -e "${GREEN}✓ Node $(node -v), npm $(npm -v), git $(git --version | cut -d' ' -f3)${NC}"

# 2. Install dependencies
echo ""
echo -e "${YELLOW}[2/6]${NC} Installing dependencies..."
npm install
echo -e "${GREEN}✓ Dependencies installed${NC}"

# 3. Set up .env
echo ""
echo -e "${YELLOW}[3/6]${NC} Setting up environment..."
if [ ! -f .env ]; then
  cp .env.example .env
  echo -e "${YELLOW}⚠  Created .env from .env.example${NC}"
  echo -e "    ${CYAN}→ Open .env and add your Anthropic API key${NC}"
  echo -e "    ${CYAN}  Get one at: https://console.anthropic.com${NC}"
else
  echo -e "${GREEN}✓ .env already exists${NC}"
fi

# 4. Test build
echo ""
echo -e "${YELLOW}[4/6]${NC} Testing build..."
npm run build > /dev/null 2>&1 && echo -e "${GREEN}✓ Build successful${NC}" || {
  echo -e "${RED}✗ Build failed. Run 'npm run build' to see errors.${NC}"
  exit 1
}

# 5. Git init
echo ""
echo -e "${YELLOW}[5/6]${NC} Initializing git repository..."
if [ ! -d .git ]; then
  git init
  git add .
  git commit -m "feat: initial commit — NEXUS v5.1 Multi-Agent AI Trading System

- 5 AI trading agents with live Claude-powered chat
- Real-time Binance WebSocket (BTC/ETH) + Yahoo Finance (stocks/metals/forex)
- Quantum-enhanced Monte Carlo simulation (500 paths, xorshift32 entropy)
- Vectorless RAG engine with live market context injection
- Cybersecurity suite with threat feed and security score gauge
- Mercury MCP bank integration
- Secure 4-step withdrawal system with 2FA
- Global news panel with sentiment tagging
- Consensus voting engine across all 5 agents"
  echo -e "${GREEN}✓ Initial commit created${NC}"
else
  echo -e "${GREEN}✓ Git already initialized${NC}"
fi

# 6. Push instructions
echo ""
echo -e "${YELLOW}[6/6]${NC} Ready to push to GitHub!"
echo ""
echo "────────────────────────────────────────"
echo -e "${CYAN}Next steps:${NC}"
echo ""
echo -e "  1. Create a new repo at ${CYAN}https://github.com/new${NC}"
echo -e "     Name: ${CYAN}nexus-trading-system${NC}"
echo -e "     Description: ${CYAN}Multi-Agent AI Trading System — real-time market data, quantum Monte Carlo, 5 AI agents${NC}"
echo -e "     Visibility: ${CYAN}Public${NC}"
echo -e "     ${YELLOW}⚠  Do NOT initialize with README (we have one)${NC}"
echo ""
echo -e "  2. Connect and push:"
echo -e "     ${CYAN}git remote add origin https://github.com/YOUR_USERNAME/nexus-trading-system.git${NC}"
echo -e "     ${CYAN}git branch -M main${NC}"
echo -e "     ${CYAN}git push -u origin main${NC}"
echo ""
echo -e "  3. Create first release:"
echo -e "     ${CYAN}git tag v5.1.0${NC}"
echo -e "     ${CYAN}git push origin v5.1.0${NC}"
echo -e "     ${CYAN}# GitHub Actions will auto-create the release!${NC}"
echo ""
echo -e "  4. Add GitHub Secrets (for CI):"
echo -e "     Repo Settings → Secrets → Actions → New secret"
echo -e "     ${CYAN}VITE_ANTHROPIC_KEY${NC} = your Anthropic API key"
echo ""
echo -e "  5. Add repository topics on GitHub:"
echo -e "     ${CYAN}trading, ai, react, fintech, claude, monte-carlo, real-time, binance${NC}"
echo ""
echo -e "  6. Start dev server:"
echo -e "     ${CYAN}npm run dev${NC}"
echo ""
echo "────────────────────────────────────────"
echo -e "${GREEN}◈ NEXUS is ready for launch! 🚀${NC}"
echo ""
