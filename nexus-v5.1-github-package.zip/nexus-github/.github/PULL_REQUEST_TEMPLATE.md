## Summary

<!-- What does this PR do? One paragraph. -->

## Type of Change

- [ ] 🐛 Bug fix (non-breaking change that fixes an issue)
- [ ] ✨ New feature (non-breaking change that adds functionality)
- [ ] 💥 Breaking change (fix or feature that would cause existing functionality to change)
- [ ] 📚 Documentation update
- [ ] 🔧 Refactor / code cleanup
- [ ] ⚡ Performance improvement
- [ ] 🔒 Security fix

## Related Issues

Closes #<!-- issue number -->

## Changes Made

<!-- Bullet list of specific changes -->
- 
- 
- 

## Testing

<!-- How did you test this? What browsers/environments? -->

- [ ] Tested in Chrome
- [ ] Tested in Firefox
- [ ] Tested in Safari
- [ ] Tested on mobile
- [ ] `npm run build` passes
- [ ] `npm run lint` passes (or acceptable warnings)

## Screenshots

<!-- For UI changes, before/after screenshots are very helpful -->

| Before | After |
|--------|-------|
| | |

## Checklist

- [ ] My code follows the existing style and patterns
- [ ] I have not hardcoded any API keys or secrets
- [ ] Existing functionality is not broken
- [ ] I have updated documentation if needed
- [ ] CHANGELOG.md updated (for significant changes)
