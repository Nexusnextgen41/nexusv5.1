---
name: 💡 Feature Request
about: Suggest a new feature or improvement
title: '[FEAT] '
labels: ['enhancement']
assignees: ''
---

## 💡 Feature Summary

<!-- One sentence describing the feature -->

## Problem / Motivation

<!-- What problem does this solve? What's the current pain point? -->

## Proposed Solution

<!-- Describe how you'd like this to work -->

## Implementation Ideas

<!-- Optional: technical thoughts on how to implement it -->

## Alternatives Considered

<!-- What other solutions did you consider? Why is this better? -->

## Would you implement this?

- [ ] Yes, I'm willing to open a PR for this
- [ ] No, but I'd be happy to help review/test
- [ ] No, just suggesting

## Additional Context

<!-- Mockups, examples from other apps, related issues, etc. -->

## Checklist

- [ ] I searched existing issues and this is not a duplicate
- [ ] This feature aligns with NEXUS being an educational trading dashboard
