---
name: 🐛 Bug Report
about: Something isn't working as expected
title: '[BUG] '
labels: ['bug', 'needs-triage']
assignees: ''
---

## 🐛 Bug Description

<!-- A clear and concise description of what the bug is -->

## Steps to Reproduce

1. Go to tab '...'
2. Click on '...'
3. Enter '...'
4. See error

## Expected Behavior

<!-- What you expected to happen -->

## Actual Behavior

<!-- What actually happened -->

## Screenshots / Console Errors

<!-- If applicable, add screenshots or paste console errors -->

```
Paste console errors here
```

## Environment

- **Browser:** [e.g. Chrome 124, Firefox 126, Safari 17]
- **OS:** [e.g. macOS 14, Windows 11, Ubuntu 22]
- **Node version:** [e.g. 20.11.0]
- **NEXUS version:** [e.g. v5.1.0]

## Additional Context

<!-- Any other relevant information about the problem -->

## Checklist

- [ ] I searched existing issues and this is not a duplicate
- [ ] I have included steps to reproduce
- [ ] I have included console errors (if any)
