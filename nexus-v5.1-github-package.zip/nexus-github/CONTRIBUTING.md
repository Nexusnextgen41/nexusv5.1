# Contributing to NEXUS

First off — thank you for considering contributing! Every PR, issue, and suggestion helps.

## 📋 Table of Contents

- [Code of Conduct](#code-of-conduct)
- [How to Contribute](#how-to-contribute)
- [Development Setup](#development-setup)
- [Pull Request Process](#pull-request-process)
- [Issue Guidelines](#issue-guidelines)
- [Good First Issues](#good-first-issues)

---

## Code of Conduct

Be excellent to each other. No harassment, discrimination, or toxic behavior.
This is a technical community focused on building good software.

---

## How to Contribute

### 🐛 Found a bug?

1. Search [existing issues](../../issues) first
2. If not found, open a [Bug Report](../../issues/new?template=bug_report.md)
3. Include: browser, steps to reproduce, expected vs actual behavior

### 💡 Have a feature idea?

1. Open a [Feature Request](../../issues/new?template=feature_request.md)
2. Describe the use case and proposed solution
3. Wait for feedback before starting a large implementation

### 🔧 Want to fix something?

1. Comment on the issue to claim it
2. Fork → branch → code → PR

---

## Development Setup

```bash
# 1. Fork the repo on GitHub

# 2. Clone your fork
git clone https://github.com/YOUR_USERNAME/nexus-trading-system.git
cd nexus-trading-system

# 3. Add upstream remote
git remote add upstream https://github.com/ORIGINAL_OWNER/nexus-trading-system.git

# 4. Install dependencies
npm install

# 5. Copy env file
cp .env.example .env
# Add your Anthropic API key to .env

# 6. Start dev server
npm run dev
```

---

## Pull Request Process

### Branch Naming

```
feat/short-description       # new feature
fix/short-description        # bug fix
docs/short-description       # documentation only
refactor/short-description   # code cleanup
perf/short-description       # performance improvement
```

### Commit Messages (Conventional Commits)

```
feat: add Coinbase WebSocket as alternative crypto feed
fix: prevent NaN in portfolio P&L when price unavailable
docs: update Mercury integration setup guide
refactor: extract price formatting into shared utility
perf: debounce Yahoo Finance polling to reduce CORS calls
```

### PR Checklist

Before opening your PR, confirm:

- [ ] Code runs without errors (`npm run dev`)
- [ ] Build passes (`npm run build`)
- [ ] No new console errors or warnings
- [ ] Existing functionality is not broken
- [ ] New features are documented in the PR description
- [ ] README updated if the feature is user-facing
- [ ] No API keys or secrets committed

### Review Process

1. Open PR against `main`
2. Automated CI checks run (lint + build)
3. Maintainer review within 3–5 days
4. Address feedback, push updates
5. Merge on approval ✓

---

## Issue Guidelines

### Bug Reports — include:
- **Environment:** Browser, OS, Node version
- **Steps to reproduce:** numbered list
- **Expected behavior:** what should happen
- **Actual behavior:** what does happen
- **Console errors:** paste any errors from DevTools
- **Screenshots:** if relevant

### Feature Requests — include:
- **Problem it solves:** what's the user pain point?
- **Proposed solution:** how would it work?
- **Alternatives considered:** other ways to solve it
- **Willingness to implement:** are you offering to build it?

---

## Good First Issues

New to the codebase? These are well-scoped contributions:

| Area | Task | Difficulty |
|------|------|------------|
| Data | Add Coinbase Pro WebSocket as fallback crypto feed | ⭐ Easy |
| Data | Add more Yahoo Finance tickers to default list | ⭐ Easy |
| UI | Add keyboard shortcut (1–8) to switch tabs | ⭐ Easy |
| UI | Add dark/light theme toggle | ⭐⭐ Medium |
| Charts | Add volume bar chart below Monte Carlo | ⭐⭐ Medium |
| Data | Add Polygon.io as alternative stock feed | ⭐⭐ Medium |
| Feature | Add portfolio performance chart (equity curve) | ⭐⭐ Medium |
| Feature | Add alert system (price threshold notifications) | ⭐⭐⭐ Hard |
| Feature | Add real order book simulation | ⭐⭐⭐ Hard |

---

## Architecture Notes

The entire app is **one self-contained file**: `src/NexusTradingSystem.jsx`.

Key sections (in order):
1. Security utilities (`sanitize`, `checkRL`, etc.)
2. Constants (`AGENTS`, `TICKERS`, `BASE_P`, `VOL`, etc.)
3. Market data fetchers (`fetchStockPrice`, `fetchGold`, etc.)
4. Claude API caller (`callClaude`, `callMercury`)
5. Math engine (`gauss`, `qEntropy`, `runMC`)
6. Sub-components (`Spark`, `MCChart`, `SourceBadge`)
7. Main component (`Nexus`) — state, effects, handlers, tabs

When adding features, follow the existing patterns:
- New data sources → add fetcher function + integrate in `useEffect`
- New tabs → add to `TABS` array + add `{tab==="yourtab" && ...}` block
- New agents → add to `AGENTS` array (everything else auto-updates)

---

Thank you for contributing to NEXUS! 🚀
