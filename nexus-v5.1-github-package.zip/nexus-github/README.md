<div align="center">

<img src="https://img.shields.io/badge/NEXUS-v5.1-00FFB2?style=for-the-badge&logo=data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNMTIgMkw0IDZWMTJDNCAyMCAxMiAyMiAxMiAyMkMyMCAyMiAyMCAyMCAyMCAxMlY2TDEyIDJaIiBmaWxsPSIjMDBGRkIyIi8+PC9zdmc+" alt="NEXUS v5.1"/>

# ◈ NEXUS v5.1
### Multi-Agent AI Trading System

**Production-grade algorithmic trading dashboard** · Single React component · Zero extra dependencies

[![React](https://img.shields.io/badge/React-18+-61DAFB?style=flat-square&logo=react)](https://react.dev)
[![Claude](https://img.shields.io/badge/Claude-Sonnet_4-CC785C?style=flat-square)](https://anthropic.com)
[![Binance](https://img.shields.io/badge/Binance-WebSocket-F0B90B?style=flat-square)](https://binance.com)
[![Yahoo Finance](https://img.shields.io/badge/Yahoo-Finance_v8-6001D2?style=flat-square)](https://finance.yahoo.com)
[![License](https://img.shields.io/badge/License-MIT-00FFB2?style=flat-square)](LICENSE)
[![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen?style=flat-square)](CONTRIBUTING.md)

[Demo](#-live-demo) · [Quick Start](#-quick-start) · [Features](#-features) · [Architecture](#-architecture) · [Contributing](#-contributing)

</div>

---

## 🌐 Live Demo

> **Try it instantly** — open in [Claude.ai](https://claude.ai) as an artifact, or clone and run locally.

```bash
git clone https://github.com/YOUR_USERNAME/nexus-trading-system
cd nexus-trading-system
npm install && npm run dev
```

**→ Open `http://localhost:5173`**

---

## ✨ Features

| Module | Description | Data Source |
|--------|-------------|-------------|
| **5 AI Trading Agents** | ALPHA · OMEGA · SIGMA · DELTA · ZETA — each with live chat | Claude Sonnet 4 |
| **Real-Time Crypto** | BTC/USDT + ETH/USDT tick-by-tick | Binance WebSocket |
| **Real-Time Stocks** | AAPL · NVDA · SPY · QQQ · GOLD · EUR/USD | Yahoo Finance v8 |
| **Quantum Monte Carlo** | 500-path 30-day simulation with quantum entropy | xorshift32 + GBM |
| **Vectorless RAG** | Semantic retrieval without a vector database | Claude API |
| **Consensus Engine** | 5-agent BUY/SELL/HOLD voting per ticker | Multi-agent |
| **Cybersecurity Suite** | Threat feed · ZK-auth · AES-256-GCM labels | Simulated live |
| **Mercury Integration** | Live bank account data via MCP | Mercury MCP |
| **Portfolio Tracker** | Live P&L · Sharpe · VaR · drawdown | Live prices |
| **Secure Withdrawal** | 4-step ZK + 2FA flow with history | Validated |

---

## 🚀 Quick Start

### Prerequisites

- Node.js 18+
- React project (Vite recommended)
- [Anthropic API key](https://console.anthropic.com)

### Installation

```bash
# 1. Clone
git clone https://github.com/YOUR_USERNAME/nexus-trading-system
cd nexus-trading-system

# 2. Install dependencies (none beyond React!)
npm install

# 3. Set your API key
cp .env.example .env
# Edit .env: VITE_ANTHROPIC_KEY=sk-ant-...

# 4. Run
npm run dev
```

### Use as a Component

```jsx
// Drop into any React project — zero extra deps
import NexusTradingSystem from './src/NexusTradingSystem'

export default function App() {
  return <NexusTradingSystem />
}
```

---

## 🏗 Architecture

```
nexus-trading-system/
├── src/
│   └── NexusTradingSystem.jsx   # ← entire app (936 lines, self-contained)
├── public/
│   └── index.html
├── docs/
│   └── NEXUS-v5.1-Documentation.pdf
├── .github/
│   ├── workflows/
│   │   └── ci.yml               # lint + build check
│   └── ISSUE_TEMPLATE/
│       ├── bug_report.md
│       └── feature_request.md
├── package.json
├── vite.config.js
├── .env.example
├── CONTRIBUTING.md
├── CHANGELOG.md
└── LICENSE
```

### Data Flow

```
Binance WebSocket ──────────────────────────┐
                                             ▼
Yahoo Finance v8 ──── CORS proxy ──► Price State ──► UI Tickers
                                             │         Sparklines
                                             │         Portfolio P&L
                                             │         MC Seed Price
                                             ▼
                                    Gaussian Sim ──► Fallback (SIM mode)

User Query ──► sanitize() ──► checkRL() ──► callClaude() ──► Agent Chat
                                                          └──► RAG Engine

Withdrawal ──► validateWd() ──► Review ──► 2FA PIN ──► Execute
```

---

## 📡 Live Data Sources

### Crypto — Binance WebSocket
```
wss://stream.binance.com:9443/stream?streams=btcusdt@ticker/ethusdt@ticker
```
Streams real-time 24hr ticker data. Auto-reconnects on close with 3s backoff.

### Stocks / Metals / Forex — Yahoo Finance v8
```
https://query1.finance.yahoo.com/v8/finance/chart/{SYMBOL}?interval=1d&range=5d
```
Fetched via `https://api.allorigins.win/raw?url=...` CORS proxy. Refreshes every 90s.
Replace with your own proxy in production.

**Supported symbols:** any Yahoo Finance ticker — `AAPL`, `NVDA`, `SPY`, `QQQ`, `GC=F` (Gold), `EURUSD=X`, `BTC-USD`, etc.

---

## 🧮 Quantum Monte Carlo

The simulation engine blends classical GBM with quantum-inspired noise:

```
r_t = (μ - ½σ²)·Δt + σ·√Δt · (0.85·N(0,1) + 0.15·Q(seed, t))

Q(seed, t) = xorshift32(seed) / 0xFFFFFFFF · cos(t · π/10)
```

- **500 paths** over **30 days** (configurable)
- Outputs: P05 / P25 / P50 / P75 / P95 bands, VaR 95%, CVaR 95%, quantum coherence score
- Seeded with the **live market price** at simulation time
- Pure SVG visualization — no charting library needed

---

## 🤖 AI Agents

Each agent receives a system prompt with:
- Live prices for all 8 tickers injected at call time
- Current portfolio positions and cash
- Agent-specific role and specialty
- Last 8 turns of conversation history

```
ALPHA  ◈  Trend Analyst      Momentum & breakout patterns
OMEGA  ⬡  Risk Manager       Portfolio hedging & exposure
SIGMA  ◎  Sentiment Oracle   NLP news & social signals
DELTA  ◆  Arbitrage Hunter   Cross-market inefficiencies
ZETA   ⬟  Macro Strategist   Economic data correlation
```

---

## 🔐 Security

| Layer | Implementation |
|-------|---------------|
| Input Sanitization | Strips `< > " ' \` \\`, truncates to 500 chars |
| Numeric Validation | Rejects NaN, Infinity, negative values |
| Rate Limiting | 10 Claude API calls / 60s, client-side enforced |
| Address Masking | Shows `XXXXXX...XXXX` in UI and history |
| Amount Bounds | Cannot exceed available cash balance |
| 2FA Gate | 4-digit PIN required before withdrawal |
| WS Resilience | Auto-reconnect on close, error→close chain |
| Fetch Timeout | 6s AbortSignal on all Yahoo Finance requests |

> ⚠️ **Production note:** Move `callClaude()` behind a backend proxy to protect your API key. Never expose `VITE_ANTHROPIC_KEY` in a public frontend.

---

## ⚙️ Configuration

### Add / Change Tickers

```js
// In NexusTradingSystem.jsx — top of file
const ALL_TICKERS = ["BTC/USDT", "ETH/USDT", "AAPL", "NVDA", "SPY", "QQQ", "GOLD", "EUR/USD"];
const BASE_P  = { "TSLA": 180, "MSFT": 415, /* ... */ };  // fallback prices
const VOL     = { "TSLA": 0.015, "MSFT": 0.007, /* ... */ }; // daily vol
```

### Add Crypto Pair (Binance)

```js
const CRYPTO_PAIRS = { "BTC/USDT": "btcusdt", "ETH/USDT": "ethusdt", "SOL/USDT": "solusdt" };
```

### Add an Agent

```js
const AGENTS = [
  ...AGENTS,
  { id:"kappa", name:"KAPPA", role:"DeFi Analyst",
    color:"#FF6B35", icon:"⬢", spec:"On-chain flow analysis" }
];
```

### Monte Carlo Parameters

```js
// More paths = smoother percentile bands (trades off speed)
const doMC = () => { setMcD(runMC(price, vol, 90, 2000)); }
//                                          ↑days  ↑paths
```

### Change AI Model

```js
// In callClaude() — swap to Opus for deeper analysis
model: "claude-opus-4-6"
```

---

## 🏦 Mercury Integration

NEXUS connects to Mercury bank via the [Mercury MCP server](https://mercury.com/mcp) through the Anthropic API.

**In Claude.ai:**
1. Settings → Integrations → Connect Mercury
2. Complete OAuth
3. Click **"Load Mercury Data"** in the Mercury tab

**Standalone deployment:**
```js
// Replace callMercury() with direct Mercury API:
const r = await fetch("https://api.mercury.com/api/v1/accounts", {
  headers: { Authorization: `Bearer ${MERCURY_API_KEY}` }
});
```

---

## 🤝 Contributing

Contributions are welcome! See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

```bash
# Fork → clone → branch
git checkout -b feature/your-feature-name

# Make changes, then
git commit -m "feat: add your feature"
git push origin feature/your-feature-name
# Open a Pull Request
```

**Good first issues:**
- Add new ticker sources (Coinbase, Alpha Vantage, Polygon.io)
- Improve Monte Carlo visualization (candlestick overlay)
- Add dark/light theme toggle
- Add order book simulation panel
- Implement real WebSocket for more exchanges

---

## 📋 Changelog

See [CHANGELOG.md](CHANGELOG.md) for full version history.

**v5.1** — Real-time Binance WS + Yahoo Finance, Mercury MCP, live price injection into agents/RAG  
**v5.0** — Quantum Monte Carlo, Global News Panel, Secure Withdrawal, full security audit  
**v4.2** — Initial release: 5 agents, consensus engine, RAG, cybersecurity suite  

---

## 📄 License

MIT License — see [LICENSE](LICENSE) for details.

Free to use, modify, and distribute. Attribution appreciated.

---

## ⚠️ Disclaimer

NEXUS is a **software tool for educational and development purposes only.** It does not constitute financial advice, execute real trades, or manage real funds (unless you extend it to do so). All agent signals, consensus votes, and Monte Carlo outputs are analytical demonstrations. The authors accept no liability for any financial decisions made using this software. Always consult a licensed financial advisor.

---

<div align="center">

Built with [Claude](https://anthropic.com) · [Binance API](https://binance.com) · [Yahoo Finance](https://finance.yahoo.com) · [Mercury MCP](https://mercury.com)

**⭐ Star this repo if it helped you!**

</div>
