# Security Policy

## Supported Versions

| Version | Supported |
|---------|-----------|
| 5.1.x   | ✅ Active  |
| 5.0.x   | ✅ Active  |
| < 5.0   | ❌ EOL     |

## Reporting a Vulnerability

**Please do not open a public GitHub issue for security vulnerabilities.**

To report a security issue:
1. Open a [GitHub Security Advisory](../../security/advisories/new) (private)
2. Or email with subject line `[NEXUS SECURITY] <brief description>`

Include:
- Description of the vulnerability
- Steps to reproduce
- Potential impact
- Suggested fix (if any)

You'll receive a response within **48 hours** acknowledging the report.

## Security Architecture

### Client-Side Controls (implemented)

| Control | Location | Description |
|---------|----------|-------------|
| Input sanitization | `sanitize()` | Strips XSS vectors from all user inputs |
| Numeric validation | `sanitizeNum()` | Prevents NaN/negative injection |
| Rate limiting | `checkRL()` | 10 Claude API calls / 60s |
| Address masking | `maskAddr()` | Wallet addresses never shown in full |
| Withdrawal bounds | `validateWd()` | Cannot exceed available balance |
| 2FA gate | Step 3 in withdrawal flow | PIN required before execution |
| Fetch timeout | `AbortSignal.timeout(6000)` | Prevents hanging requests |
| WS resilience | Auto-reconnect | 3s backoff, error→close chain |

### Production Hardening (your responsibility)

When deploying NEXUS in production, you **must** implement:

1. **Backend API proxy** — never expose Anthropic API keys in client-side code
2. **Server-side rate limiting** — client-side only is not sufficient
3. **Authentication** — add session/JWT auth before the dashboard
4. **CORS headers** — lock down allowed origins on your backend
5. **CSP headers** — Content-Security-Policy to prevent script injection
6. **HTTPS only** — never run over HTTP in production
7. **Dependency auditing** — run `npm audit` regularly
8. **Environment variables** — never commit `.env` files

### Known Limitations

- The `allorigins.win` CORS proxy used for Yahoo Finance is a public service — replace with your own in production
- Client-side rate limiting can be bypassed by direct API calls — always add server-side enforcement
- The 2FA PIN in the withdrawal flow is a UI demonstration — integrate with real auth in production

## Disclosure Policy

- Security fixes are released as patch versions (e.g., 5.1.1)
- Critical fixes are released immediately
- Non-critical fixes are bundled in the next minor release
- Full disclosure after 90 days or upon patch release, whichever is first
