import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import NexusTradingSystem from './NexusTradingSystem'

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <NexusTradingSystem />
  </StrictMode>,
)
