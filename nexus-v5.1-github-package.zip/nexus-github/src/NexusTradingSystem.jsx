import { useState, useEffect, useRef, useCallback } from "react";

// ─────────────────────────────────────────────
// SECURITY
// ─────────────────────────────────────────────
const sanitize = (s) => String(s ?? "").replace(/[<>"'`\\]/g, "").trim().slice(0, 500);
const sanitizeNum = (n) => { const v = parseFloat(n); return isNaN(v) || v < 0 ? 0 : v; };
const maskAddr = (a) => { const s = sanitize(a); return s.length > 10 ? `${s.slice(0,6)}...${s.slice(-4)}` : s; };
const RL = { t: 0, n: 0 };
const checkRL = () => {
  const now = Date.now();
  if (now - RL.t > 60000) { RL.t = now; RL.n = 0; }
  if (RL.n >= 10) throw new Error("Rate limit: wait 60s before next query.");
  RL.n++;
};

// ─────────────────────────────────────────────
// REAL-TIME MARKET DATA
// Sources:
//   Crypto  → Binance WebSocket (wss://stream.binance.com)
//   Stocks  → Yahoo Finance v8 JSON (CORS-friendly via allorigins proxy)
//   Metals  → metals-api via allorigins, fallback to simulation
// ─────────────────────────────────────────────
const CRYPTO_PAIRS = { "BTC/USDT": "btcusdt", "ETH/USDT": "ethusdt" };
const STOCK_SYMS   = ["AAPL", "NVDA", "SPY", "QQQ"];
const YF_PROXY     = (sym) =>
  `https://api.allorigins.win/raw?url=${encodeURIComponent(
    `https://query1.finance.yahoo.com/v8/finance/chart/${sym}?interval=1d&range=5d`
  )}`;

async function fetchStockPrice(sym) {
  try {
    const r = await fetch(YF_PROXY(sym), { signal: AbortSignal.timeout(6000) });
    if (!r.ok) throw new Error("HTTP " + r.status);
    const d = await r.json();
    const q = d?.chart?.result?.[0];
    if (!q) throw new Error("No result");
    const meta = q.meta;
    const price   = meta.regularMarketPrice ?? meta.previousClose;
    const prevClose = meta.chartPreviousClose ?? meta.previousClose ?? price;
    const chgPct  = ((price - prevClose) / prevClose) * 100;
    const closes  = q.indicators?.quote?.[0]?.close?.filter(Boolean) ?? [price];
    return { price, chgPct, history: closes };
  } catch {
    return null;
  }
}

async function fetchGold() {
  // Use Yahoo Finance GC=F (Gold Futures)
  try {
    const r = await fetch(YF_PROXY("GC=F"), { signal: AbortSignal.timeout(6000) });
    if (!r.ok) throw new Error("HTTP " + r.status);
    const d = await r.json();
    const meta = d?.chart?.result?.[0]?.meta;
    if (!meta) throw new Error("No data");
    const price = meta.regularMarketPrice ?? meta.previousClose;
    const prev  = meta.chartPreviousClose ?? meta.previousClose ?? price;
    const closes = d?.chart?.result?.[0]?.indicators?.quote?.[0]?.close?.filter(Boolean) ?? [price];
    return { price, chgPct: ((price - prev) / prev) * 100, history: closes };
  } catch { return null; }
}

async function fetchEURUSD() {
  try {
    const r = await fetch(YF_PROXY("EURUSD=X"), { signal: AbortSignal.timeout(6000) });
    if (!r.ok) throw new Error("HTTP " + r.status);
    const d = await r.json();
    const meta = d?.chart?.result?.[0]?.meta;
    if (!meta) throw new Error("No data");
    const price = meta.regularMarketPrice ?? meta.previousClose;
    const prev  = meta.chartPreviousClose ?? meta.previousClose ?? price;
    const closes = d?.chart?.result?.[0]?.indicators?.quote?.[0]?.close?.filter(Boolean) ?? [price];
    return { price, chgPct: ((price - prev) / prev) * 100, history: closes };
  } catch { return null; }
}

// ─────────────────────────────────────────────
// CONSTANTS
// ─────────────────────────────────────────────
const AGENTS = [
  { id:"alpha", name:"ALPHA", role:"Trend Analyst",    color:"#00FFB2", icon:"◈", spec:"Momentum & breakout patterns" },
  { id:"omega", name:"OMEGA", role:"Risk Manager",     color:"#FF4D6D", icon:"⬡", spec:"Portfolio hedging & exposure" },
  { id:"sigma", name:"SIGMA", role:"Sentiment Oracle", color:"#7B61FF", icon:"◎", spec:"NLP news & social signals" },
  { id:"delta", name:"DELTA", role:"Arbitrage Hunter", color:"#FFB800", icon:"◆", spec:"Cross-market inefficiencies" },
  { id:"zeta",  name:"ZETA",  role:"Macro Strategist", color:"#00D4FF", icon:"⬟", spec:"Economic data correlation" },
];
const ALL_TICKERS = ["BTC/USDT","ETH/USDT","AAPL","NVDA","SPY","QQQ","GOLD","EUR/USD"];
const FALLBACK_P  = {"BTC/USDT":96800,"ETH/USDT":1840,"AAPL":276,"NVDA":1094,"SPY":558,"QQQ":474,"GOLD":3284,"EUR/USD":1.1312};
const VOL         = {"BTC/USDT":0.011,"ETH/USDT":0.013,"AAPL":0.005,"NVDA":0.009,"SPY":0.003,"QQQ":0.004,"GOLD":0.003,"EUR/USD":0.002};

const THREATS = [
  {msg:"SQL injection probe blocked",       sev:"HIGH"},
  {msg:"DDoS vector neutralized",            sev:"HIGH"},
  {msg:"Spoofed API cert rejected",          sev:"MED"},
  {msg:"Anomalous trading pattern flagged",  sev:"MED"},
  {msg:"Rate-limit breach intercepted",      sev:"LOW"},
  {msg:"MitM attempt terminated",            sev:"HIGH"},
  {msg:"JWT token forgery attempt rejected", sev:"HIGH"},
  {msg:"Replay attack signature detected",   sev:"MED"},
  {msg:"Port scan from external IP blocked", sev:"LOW"},
  {msg:"Unauthorized key rotation blocked",  sev:"HIGH"},
];
const SYS_EVENTS = [
  "Agent consensus reached on BTC/USDT LONG",
  "RAG context refreshed — 6 documents indexed",
  "Zero-knowledge proof validated for trade",
  "Multi-sig wallet authorization confirmed",
  "SIGMA override: news sentiment shift detected",
  "OMEGA reducing exposure — VaR limit approaching",
  "DELTA found 0.23% arb gap on ETH/USDT",
  "Quantum entropy source seeded for MC simulation",
  "Monte Carlo convergence achieved (500 paths)",
  "Anomaly score below threshold — proceeding",
];
const NEWS = [
  {src:"Reuters",   hl:"Fed signals cautious stance on further rate cuts amid sticky inflation",        tag:"MACRO",  sent:"NEG",age:"2m"},
  {src:"Bloomberg", hl:"Bitcoin approaches $97k — ETF inflows hit $890M weekly record",                tag:"CRYPTO", sent:"POS",age:"5m"},
  {src:"FT",        hl:"NVIDIA posts record datacenter revenue — AI infrastructure boom continues",     tag:"EQUITY", sent:"POS",age:"9m"},
  {src:"WSJ",       hl:"China PMI contracts third straight month, raising global growth fears",         tag:"MACRO",  sent:"NEG",age:"14m"},
  {src:"CoinDesk",  hl:"Ethereum staking yields compressed as liquid staking protocols gain share",     tag:"CRYPTO", sent:"NEU",age:"18m"},
  {src:"Reuters",   hl:"AAPL supply chain disruptions ease; Taiwan production resumes full capacity",   tag:"EQUITY", sent:"POS",age:"22m"},
  {src:"Bloomberg", hl:"Gold surges past $3,280 as central banks accelerate reserve diversification",   tag:"COMMOD", sent:"POS",age:"27m"},
  {src:"FT",        hl:"ECB reaffirms June rate cut path despite EUR/USD volatility spike",             tag:"FOREX",  sent:"NEU",age:"31m"},
  {src:"WSJ",       hl:"Dark pool volume surges 18% — institutional accumulation phase confirmed",      tag:"EQUITY", sent:"POS",age:"35m"},
  {src:"Bloomberg", hl:"Quant funds rotate out of tech growth into defensive dividend plays",           tag:"MACRO",  sent:"NEG",age:"41m"},
  {src:"CNBC",      hl:"VIX spikes above 19 — options market pricing elevated near-term uncertainty",  tag:"QUANT",  sent:"NEG",age:"44m"},
  {src:"CoinDesk",  hl:"ETH Glamsterdam upgrade triples L1 capacity — gas limit to 200M",              tag:"CRYPTO", sent:"POS",age:"48m"},
];
const RAG_DOCS = [
  {id:1,title:"Q1 2026 Fed Minutes",      tokens:4821,rel:0.94,cat:"macro"},
  {id:2,title:"NVDA Earnings Transcript", tokens:8204,rel:0.88,cat:"equity"},
  {id:3,title:"BTC On-Chain Analytics",   tokens:3102,rel:0.97,cat:"crypto"},
  {id:4,title:"Volatility Surface Model", tokens:2890,rel:0.81,cat:"quant"},
  {id:5,title:"Global Macro Risk Report", tokens:6430,rel:0.85,cat:"macro"},
  {id:6,title:"Dark Pool Flow Analysis",  tokens:1920,rel:0.91,cat:"equity"},
];

// ─────────────────────────────────────────────
// MATH
// ─────────────────────────────────────────────
const rnd  = (a,b) => Math.random()*(b-a)+a;
const rndI = (a,b) => Math.floor(rnd(a,b));
const pick = (arr) => arr[rndI(0,arr.length)];
const gauss = () => {
  let u=0,v=0;
  while(!u) u=Math.random(); while(!v) v=Math.random();
  return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v);
};
const qEntropy = (seed,t) => {
  let x=(seed^(seed<<13))>>>0; x=(x^(x>>7))>>>0; x=(x^(x<<17))>>>0;
  return (x/0xFFFFFFFF)*Math.cos(t*0.31415926);
};
const runMC = (price, vol, days=30, nP=500) => {
  const dt=1/252, mu=rnd(0.0001,0.0006), seed=Date.now()|0;
  const paths=[];
  for(let p=0;p<nP;p++){
    const path=[price];
    for(let d=0;d<days;d++){
      const r=(mu-0.5*vol*vol)*dt+vol*Math.sqrt(dt)*(gauss()*0.85+qEntropy(seed+p*37+d,d*0.1)*0.15);
      path.push(Math.max(price*0.1,path[path.length-1]*Math.exp(r)));
    }
    paths.push(path);
  }
  const sum=[];
  for(let d=0;d<=days;d++){
    const vs=paths.map(p=>p[d]).sort((a,b)=>a-b);
    sum.push({d,p05:vs[Math.floor(nP*.05)],p25:vs[Math.floor(nP*.25)],p50:vs[Math.floor(nP*.50)],p75:vs[Math.floor(nP*.75)],p95:vs[Math.floor(nP*.95)]});
  }
  const fin=paths.map(p=>p[days]).sort((a,b)=>a-b);
  const k=Math.floor(nP*.05);
  return {sum,paths:paths.slice(0,80),var95:fin[k],
    cvar95:fin.slice(0,k).reduce((a,v)=>a+v,0)/Math.max(k,1),
    median:fin[Math.floor(nP*.5)],bull:fin[Math.floor(nP*.85)],bear:fin[Math.floor(nP*.15)],
    qc:Math.abs(qEntropy(seed,days*.31)).toFixed(4)};
};

// ─────────────────────────────────────────────
// CLAUDE API
// ─────────────────────────────────────────────
async function callClaude(sys, usr) {
  checkRL();
  const r = await fetch("https://api.anthropic.com/v1/messages", {
    method:"POST", headers:{"Content-Type":"application/json"},
    body: JSON.stringify({
      model:"claude-sonnet-4-20250514", max_tokens:1000,
      system: sanitize(sys).slice(0,2000),
      messages:[{role:"user",content:sanitize(usr).slice(0,1000)}]
    })
  });
  if(!r.ok) throw new Error(`HTTP ${r.status}`);
  const d = await r.json();
  if(d.error) throw new Error(d.error.message);
  return d.content?.map(b=>b.text||"").join("")||"";
}

// ─────────────────────────────────────────────
// MERCURY MCP CALL
// ─────────────────────────────────────────────
async function callMercury(tool, input={}) {
  const r = await fetch("https://api.anthropic.com/v1/messages", {
    method:"POST", headers:{"Content-Type":"application/json"},
    body: JSON.stringify({
      model:"claude-sonnet-4-20250514", max_tokens:1000,
      system:"You are a financial assistant with Mercury bank access. Use the Mercury MCP tools to retrieve account data. Return ONLY a JSON object with the requested data, no prose.",
      messages:[{role:"user",content:`Call Mercury tool: ${tool}. Input: ${JSON.stringify(input)}. Return raw JSON result.`}],
      mcp_servers:[{type:"url",url:"https://mcp.mercury.com/mcp",name:"mercury"}]
    })
  });
  if(!r.ok) throw new Error(`Mercury API HTTP ${r.status}`);
  const d = await r.json();
  // Extract tool result or text from response
  const toolResult = d.content?.find(b=>b.type==="mcp_tool_result");
  if(toolResult?.content?.[0]?.text) {
    try { return JSON.parse(toolResult.content[0].text); } catch { return toolResult.content[0].text; }
  }
  const textBlock = d.content?.find(b=>b.type==="text");
  if(textBlock?.text) {
    try { return JSON.parse(textBlock.text.replace(/```json|```/g,"").trim()); } catch { return textBlock.text; }
  }
  throw new Error("No usable Mercury response");
}

// ─────────────────────────────────────────────
// COMPONENTS
// ─────────────────────────────────────────────
const C={bg:"#020408",pan:"#07090E",bdr:"#0D1B26",mut:"#3A5565",acc:"#00FFB2",red:"#FF4D6D",pur:"#7B61FF",gld:"#FFB800",blu:"#00D4FF"};
const Lbl=({t})=><div style={{color:C.mut,fontSize:9,letterSpacing:3,textTransform:"uppercase",marginBottom:9}}>{t}</div>;

// Price format helper
const fmtP = (p) => p >= 10000 ? p.toFixed(0) : p >= 100 ? p.toFixed(2) : p >= 1 ? p.toFixed(3) : p.toFixed(5);

function Spark({data,color,w=120,h=28}){
  if(!data||data.length<2) return null;
  const valid=data.filter(v=>v!=null&&!isNaN(v));
  if(valid.length<2) return null;
  const mn=Math.min(...valid),mx=Math.max(...valid),rng=mx-mn||1;
  const pts=valid.map((v,i)=>`${(i/(valid.length-1))*w},${h-((v-mn)/rng)*(h-2)+1}`).join(" ");
  const gid=`g${color.replace(/[^a-z0-9]/gi,"")}${w}`;
  return <svg width={w} height={h} style={{display:"block"}}>
    <defs><linearGradient id={gid} x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor={color} stopOpacity=".2"/><stop offset="100%" stopColor={color} stopOpacity="0"/></linearGradient></defs>
    <polygon points={`0,${h} ${pts} ${w},${h}`} fill={`url(#${gid})`}/>
    <polyline points={pts} fill="none" stroke={color} strokeWidth="1.5" strokeLinejoin="round"/>
  </svg>;
}

function MCChart({mc,color,w=620,h=210}){
  if(!mc?.sum?.length) return null;
  const {sum,paths}=mc,D=sum.length;
  const allV=sum.flatMap(d=>[d.p05,d.p95]).filter(v=>v!=null&&isFinite(v));
  if(!allV.length) return null;
  const mn=Math.min(...allV),mx=Math.max(...allV),rng=mx-mn||1;
  const px=d=>(d/(D-1))*(w-24)+12;
  const py=v=>h-8-((Math.max(mn,Math.min(mx,v))-mn)/rng)*(h-18);
  const band=(k1,k2,col,op)=>{
    const t=sum.map((d,i)=>`${px(i)},${py(d[k2])}`).join(" ");
    const b=sum.map((d,i)=>`${px(D-1-i)},${py(sum[D-1-i][k1])}`).join(" ");
    return <polygon key={k1+k2} points={`${t} ${b}`} fill={col} opacity={op}/>;
  };
  const ln=(k,col,sw=1.2)=><polyline key={k} points={sum.map((d,i)=>`${px(i)},${py(d[k])}`).join(" ")} fill="none" stroke={col} strokeWidth={sw} strokeLinejoin="round"/>;
  return <svg width={w} height={h} style={{display:"block",overflow:"visible"}}>
    <line x1={12} y1={8} x2={12} y2={h-8} stroke="#0D1B26" strokeWidth="1"/>
    <line x1={12} y1={h-8} x2={w-12} y2={h-8} stroke="#0D1B26" strokeWidth="1"/>
    {Array.from({length:5},(_,i)=>{const y=8+i*(h-18)/4;return <line key={i} x1={12} y1={y} x2={w-12} y2={y} stroke="#0D1B2628" strokeWidth="0.5"/>;} )}
    {band("p05","p95","#0D1E30",0.7)}{band("p25","p75",color,0.10)}
    {paths?.slice(0,60).map((p,pi)=><polyline key={pi} points={p.map((v,i)=>`${px(i)},${py(v)}`).join(" ")} fill="none" stroke={color} strokeWidth="0.4" opacity="0.10" strokeLinejoin="round"/>)}
    {ln("p05",`${C.red}55`,0.9)}{ln("p95",`${C.acc}55`,0.9)}
    {ln("p25",`${color}55`,1)}{ln("p75",`${color}55`,1)}{ln("p50",color,2.2)}
    <text x={w-14} y={py(sum[D-1].p95)+4} fontSize="8" fill={`${C.acc}80`} textAnchor="end">P95</text>
    <text x={w-14} y={py(sum[D-1].p50)+4} fontSize="8" fill={color} textAnchor="end">MED</text>
    <text x={w-14} y={py(sum[D-1].p05)+4} fontSize="8" fill={`${C.red}80`} textAnchor="end">P05</text>
  </svg>;
}

// ─────────────────────────────────────────────
// DATA SOURCE BADGE
// ─────────────────────────────────────────────
function SourceBadge({src}){
  const map={LIVE:{col:C.acc,label:"● LIVE"},SIM:{col:C.gld,label:"◌ SIM"},STALE:{col:"#FF884D",label:"⚠ STALE"}};
  const s=map[src]||map.SIM;
  return <span style={{fontSize:7,color:s.col,padding:"1px 5px",background:`${s.col}15`,borderRadius:6,letterSpacing:1}}>{s.label}</span>;
}

// ─────────────────────────────────────────────
// MAIN APP
// ─────────────────────────────────────────────
export default function Nexus(){
  const [tab,setTab]=useState("dashboard");

  // Market data state — initialized with fallbacks, upgraded with real data
  const [prices,setPrices]=useState(()=>
    ALL_TICKERS.reduce((a,t)=>({...a,[t]:{
      price:FALLBACK_P[t], prev:FALLBACK_P[t], chg:0,
      hist:Array.from({length:40},()=>FALLBACK_P[t]*(1+rnd(-0.015,0.015))),
      source:"SIM", lastUpdate:null
    }}),{})
  );
  const [dataStatus,setDataStatus]=useState("INITIALIZING"); // LIVE | PARTIAL | OFFLINE
  const wsRef=useRef(null);

  // Agent / system state
  const [agSt,setAgSt]=useState(AGENTS.reduce((a,ag)=>({...a,[ag.id]:{status:"IDLE",sig:"HOLD",conf:50,last:"Initializing..."}}),{}));
  const [votes,setVotes]=useState({});
  const [logs,setLogs]=useState([]);
  const [threats,setThreats]=useState([]);
  const [secSc,setSecSc]=useState(97.4);
  const [net,setNet]=useState({lat:12,up:99.98,nd:7});

  // RAG
  const [ragQ,setRagQ]=useState(""); const [ragR,setRagR]=useState([]); const [ragL,setRagL]=useState(false);

  // Agent chat
  const [selAg,setSelAg]=useState(AGENTS[0]);
  const [chat,setChat]=useState([]); const [chatIn,setChatIn]=useState(""); const [chatL,setChatL]=useState(false);
  const chatBot=useRef(null);

  // Portfolio
  const [port,setPort]=useState({cash:84210.44,pos:[
    {ticker:"BTC/USDT",size:0.42,entry:61200,pnl:0},
    {ticker:"NVDA",    size:12,  entry:842,  pnl:0},
    {ticker:"ETH/USDT",size:3.1, entry:3280, pnl:0},
  ]});

  // Mercury
  const [mercuryAccounts,setMercuryAccounts]=useState(null);
  const [mercuryLoading,setMercuryLoading]=useState(false);
  const [mercuryError,setMercuryError]=useState("");
  const [mercuryTxns,setMercuryTxns]=useState(null);

  // Withdrawal
  const [wdAmt,setWdAmt]=useState(""); const [wdAddr,setWdAddr]=useState(""); const [wdAsset,setWdAsset]=useState("USDT");
  const [wdStep,setWdStep]=useState(1); const [wdPin,setWdPin]=useState("");
  const [wdErr,setWdErr]=useState(""); const [wdLoad,setWdLoad]=useState(false);
  const [wdHist,setWdHist]=useState([
    {id:"WD-8821",amt:2500, asset:"USDT",to:"0x3f8a...b214",st:"CONFIRMED",ts:"2026-05-02 14:32"},
    {id:"WD-8819",amt:0.15, asset:"BTC", to:"bc1qxy...9f3a",st:"CONFIRMED",ts:"2026-05-01 09:14"},
    {id:"WD-8815",amt:15000,asset:"USDT",to:"0x3f8a...b214",st:"CONFIRMED",ts:"2026-04-28 18:55"},
  ]);

  // Monte Carlo
  const [mcT,setMcT]=useState("BTC/USDT"); const [mcD,setMcD]=useState(null); const [mcRun,setMcRun]=useState(false);
  const [nFilt,setNFilt]=useState("ALL");
  const [clk,setClk]=useState(new Date());

  // ─── REAL-TIME DATA BOOTSTRAP ─────────────
  // 1) Fetch stocks + metals + forex via Yahoo Finance
  useEffect(()=>{
    let cancelled=false;
    const fetchAll=async()=>{
      setDataStatus("LOADING");
      const results={};
      let liveCount=0;

      // Stocks
      await Promise.all(STOCK_SYMS.map(async sym=>{
        const d=await fetchStockPrice(sym);
        if(d&&!cancelled){
          results[sym]={
            price:d.price, prev:d.price*(1-d.chgPct/100),
            chg:d.chgPct,
            hist:d.history.length>1?d.history:Array.from({length:20},()=>d.price*(1+rnd(-0.02,0.02))),
            source:"LIVE", lastUpdate:Date.now()
          };
          liveCount++;
        }
      }));

      // Gold
      const gold=await fetchGold();
      if(gold&&!cancelled){
        results["GOLD"]={price:gold.price,prev:gold.price*(1-gold.chgPct/100),chg:gold.chgPct,
          hist:gold.history.length>1?gold.history:Array.from({length:20},()=>gold.price*(1+rnd(-0.01,0.01))),
          source:"LIVE",lastUpdate:Date.now()};
        liveCount++;
      }

      // EUR/USD
      const eur=await fetchEURUSD();
      if(eur&&!cancelled){
        results["EUR/USD"]={price:eur.price,prev:eur.price*(1-eur.chgPct/100),chg:eur.chgPct,
          hist:eur.history.length>1?eur.history:Array.from({length:20},()=>eur.price*(1+rnd(-0.005,0.005))),
          source:"LIVE",lastUpdate:Date.now()};
        liveCount++;
      }

      if(!cancelled&&Object.keys(results).length>0){
        setPrices(prev=>({...prev,...results}));
        setDataStatus(liveCount>=5?"LIVE":"PARTIAL");
      }
    };
    fetchAll();
    // Re-fetch stocks every 90s (Yahoo rate limit friendly)
    const iv=setInterval(fetchAll,90000);
    return ()=>{ cancelled=true; clearInterval(iv); };
  },[]);

  // 2) Binance WebSocket for crypto real-time
  useEffect(()=>{
    const streams=Object.values(CRYPTO_PAIRS).map(s=>`${s}@ticker`).join("/");
    let ws;
    const connect=()=>{
      try{
        ws=new WebSocket(`wss://stream.binance.com:9443/stream?streams=${streams}`);
        wsRef.current=ws;
        ws.onopen=()=>{ setDataStatus(s=>s==="LIVE"?"LIVE":"PARTIAL"); };
        ws.onmessage=(e)=>{
          try{
            const msg=JSON.parse(e.data);
            const d=msg.data;
            if(!d) return;
            const ticker=Object.entries(CRYPTO_PAIRS).find(([,v])=>v===d.s?.toLowerCase())?.[0];
            if(!ticker) return;
            const price=parseFloat(d.c);
            const prev=parseFloat(d.o);
            const chg=((price-prev)/prev)*100;
            setPrices(prev2=>({
              ...prev2,
              [ticker]:{
                price, prev,chg,
                hist:[...(prev2[ticker]?.hist??[]).slice(-39),price],
                source:"LIVE",lastUpdate:Date.now()
              }
            }));
            setDataStatus("LIVE");
          }catch{}
        };
        ws.onclose=()=>{ setDataStatus(s=>s!=="LIVE"?s:"PARTIAL"); setTimeout(connect,3000); };
        ws.onerror=()=>{ ws.close(); };
      }catch{}
    };
    connect();
    return ()=>{ ws?.close(); wsRef.current=null; };
  },[]);

  // 3) Simulation drift for any ticker still in SIM mode (fallback only)
  useEffect(()=>{
    const iv=setInterval(()=>{
      setPrices(prev=>{
        const nx={...prev};
        ALL_TICKERS.forEach(t=>{
          if(nx[t].source==="SIM"){
            const g=gauss()*VOL[t]*0.25;
            const p=Math.max(nx[t].price*0.3,nx[t].price*(1+g));
            nx[t]={...nx[t],price:p,prev:nx[t].price,chg:((p-FALLBACK_P[t])/FALLBACK_P[t])*100,
              hist:[...nx[t].hist.slice(1),p]};
          }
          // Also extend hist for LIVE tickers to keep sparklines moving
          if(nx[t].source==="LIVE"&&nx[t].hist.length<8){
            nx[t]={...nx[t],hist:[...nx[t].hist,nx[t].price*(1+gauss()*VOL[t]*0.1)]};
          }
        });
        return nx;
      });
    },2500);
    return ()=>clearInterval(iv);
  },[]);

  // Portfolio live P&L
  useEffect(()=>{
    setPort(prev=>({...prev,pos:prev.pos.map(p=>({...p,pnl:(prices[p.ticker]?.price??p.entry-p.entry)*p.size}))}));
  },[prices]);

  // System intervals
  useEffect(()=>{
    const iv=setInterval(()=>{setLogs(l=>[{ts:new Date().toLocaleTimeString(),msg:pick(SYS_EVENTS),id:Date.now()+Math.random()},...l].slice(0,80));},2500);
    return ()=>clearInterval(iv);
  },[]);
  useEffect(()=>{
    const iv=setInterval(()=>{
      setThreats(p=>[{...pick(THREATS),ts:new Date().toLocaleTimeString(),id:Date.now()},...p].slice(0,40));
      setSecSc(s=>Math.min(100,Math.max(88,s+rnd(-0.3,0.4))));
      setNet(n=>({...n,lat:Math.max(7,Math.round(n.lat+rnd(-1.5,1.5)))}));
    },3000);
    return ()=>clearInterval(iv);
  },[]);
  useEffect(()=>{
    const iv=setInterval(()=>{
      const ag=pick(AGENTS);
      setAgSt(prev=>({...prev,[ag.id]:{status:pick(["SCANNING","ANALYZING","EXECUTING","MONITORING","IDLE"]),sig:pick(["STRONG BUY","BUY","HOLD","SELL","STRONG SELL"]),conf:rndI(52,99),last:pick(SYS_EVENTS)}}));
      setVotes(AGENTS.reduce((a,x)=>({...a,[x.id]:pick(["BUY","SELL","HOLD"])}),{}));
    },2000);
    return ()=>clearInterval(iv);
  },[]);
  useEffect(()=>{const iv=setInterval(()=>setClk(new Date()),1000);return()=>clearInterval(iv);},[]);
  useEffect(()=>{chatBot.current?.scrollIntoView({behavior:"smooth"});},[chat,chatL]);

  // MC
  const doMC=useCallback(()=>{
    setMcRun(true);
    setTimeout(()=>{setMcD(runMC(prices[mcT]?.price||FALLBACK_P[mcT],VOL[mcT]||0.01));setMcRun(false);},400);
  },[mcT,prices]);
  useEffect(()=>{doMC();},[mcT]);

  // Mercury load
  const loadMercury=useCallback(async()=>{
    setMercuryLoading(true); setMercuryError("");
    try{
      const accts=await callMercury("load_accounts_card");
      setMercuryAccounts(accts);
      // Try loading recent transactions for first account
      if(accts?.accounts?.[0]?.id||accts?.[0]?.id){
        const acctId=accts?.accounts?.[0]?.id||accts?.[0]?.id;
        try{
          const txns=await callMercury("load_account_statement",{accountId:acctId,limit:10});
          setMercuryTxns(txns);
        }catch{}
      }
    }catch(e){setMercuryError(String(e?.message||"Mercury connection failed. Ensure Mercury MCP is connected."));}
    setMercuryLoading(false);
  },[]);

  // Handlers
  const doRAG=useCallback(async()=>{
    const q=sanitize(ragQ); if(!q) return;
    setRagL(true); setRagR([]);
    try{
      const priceCtx=ALL_TICKERS.map(t=>`${t}: $${fmtP(prices[t]?.price||0)} (${prices[t]?.chg>=0?"+":""}${(prices[t]?.chg||0).toFixed(2)}%)`).join(", ");
      const res=await callClaude(
        "You are a financial RAG engine with real-time market access. Return ONLY a JSON array of 3 objects each with: title, snippet(2 concise sentences incorporating current prices if relevant), relevance(float 0-1), category(macro|equity|crypto|quant). No markdown.",
        `Query: "${q}"\nCurrent prices: ${priceCtx}\nDocs: ${RAG_DOCS.map(d=>d.title).join(", ")}`
      );
      const parsed=JSON.parse(res.replace(/```(?:json)?|```/g,"").trim());
      setRagR(Array.isArray(parsed)?parsed:[]);
    }catch(e){setRagR([{title:"Error",snippet:String(e?.message||"Parse error"),relevance:0,category:"error"}]);}
    setRagL(false);
  },[ragQ,prices]);

  const doChat=useCallback(async()=>{
    const msg=sanitize(chatIn); if(!msg||chatL) return;
    setChatIn(""); setChatL(true);
    setChat(p=>[...p,{role:"user",content:msg}]);
    try{
      const priceCtx=ALL_TICKERS.map(t=>`${t}=$${fmtP(prices[t]?.price||0)}(${prices[t]?.chg>=0?"+":""}${(prices[t]?.chg||0).toFixed(2)}%)`).join(" ");
      const hist=chat.slice(-8).map(m=>`${m.role==="user"?"Human":selAg.name}: ${m.content}`).join("\n");
      const res=await callClaude(
        `You are ${selAg.name}, AI trading agent specializing in ${selAg.spec} (${selAg.role}). LIVE PRICES: ${priceCtx}. Cash: $84,210. Positions: BTC×0.42, NVDA×12, ETH×3.1. Be concise and data-driven. Max 130 words.`,
        hist?`${hist}\nHuman: ${msg}`:msg
      );
      setChat(p=>[...p,{role:"assistant",content:res}]);
    }catch(e){setChat(p=>[...p,{role:"assistant",content:`⚠ ${e?.message||"Channel error."}`}]);}
    setChatL(false);
  },[chatIn,chatL,selAg,chat,prices]);

  const wdValidate=()=>{
    const a=sanitizeNum(wdAmt),addr=sanitize(wdAddr);
    if(a<=0) return "Enter a valid withdrawal amount.";
    const avail=mercuryAccounts?parseFloat(mercuryAccounts?.accounts?.[0]?.availableBalance??mercuryAccounts?.[0]?.availableBalance??port.cash):port.cash;
    if(a>avail) return `Insufficient funds. Available: $${avail.toFixed(2)}`;
    if(addr.length<10) return "Wallet address must be at least 10 characters.";
    if(!/^[a-zA-Z0-9]+$/.test(addr.replace(/[.]/g,""))) return "Invalid address characters detected.";
    return "";
  };

  // Derived
  const totPnl=port.pos.reduce((s,p)=>s+(prices[p.ticker]?.price??p.entry-p.entry>0?(prices[p.ticker]?.price-p.entry)*p.size:0),0);
  const totVal=port.cash+port.pos.reduce((s,p)=>s+(prices[p.ticker]?.price||p.entry)*p.size,0);
  const pnlPct=totPnl/totVal*100;
  const fNews=nFilt==="ALL"?NEWS:NEWS.filter(n=>n.tag===nFilt);
  const liveCount=ALL_TICKERS.filter(t=>prices[t]?.source==="LIVE").length;

  const dsColor={LIVE:C.acc,PARTIAL:C.gld,OFFLINE:C.red,INITIALIZING:C.mut,LOADING:C.blu}[dataStatus]||C.mut;

  const TABS=[
    {id:"dashboard",lb:"DASHBOARD"},{id:"agents",lb:"AGENTS"},{id:"montecarlo",lb:"MONTE CARLO"},
    {id:"rag",lb:"RAG ENGINE"},{id:"security",lb:"CYBER SUITE"},{id:"portfolio",lb:"PORTFOLIO"},
    {id:"mercury",lb:"MERCURY"},{id:"withdraw",lb:"WITHDRAW"},
  ];

  return (
    <div style={{fontFamily:"'Courier New',Consolas,monospace",background:C.bg,minHeight:"100vh",color:"#B0C2CC",fontSize:"12px",position:"relative"}}>
      <div style={{position:"fixed",inset:0,zIndex:0,backgroundImage:`linear-gradient(${C.acc}06 1px,transparent 1px),linear-gradient(90deg,${C.acc}06 1px,transparent 1px)`,backgroundSize:"48px 48px",pointerEvents:"none"}}/>
      <div style={{position:"relative",zIndex:2,maxWidth:1440,margin:"0 auto",padding:"12px 16px"}}>

        {/* ─── HEADER ─── */}
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12,paddingBottom:9,borderBottom:`1px solid ${C.bdr}`}}>
          <div>
            <div style={{fontSize:19,fontWeight:700,color:C.acc,letterSpacing:5,textShadow:`0 0 18px ${C.acc}40`}}>◈ NEXUS v5.1</div>
            <div style={{color:C.mut,fontSize:8,letterSpacing:3,marginTop:1}}>MULTI-AGENT · QUANTUM-MC · REAL-TIME MARKET · VECTORLESS RAG · CYBER HARDENED</div>
          </div>
          <div style={{display:"flex",gap:16,alignItems:"center"}}>
            {/* Data status */}
            <div style={{padding:"6px 12px",background:`${dsColor}10`,border:`1px solid ${dsColor}35`,borderRadius:4,textAlign:"center"}}>
              <div style={{color:dsColor,fontSize:11,fontWeight:700,letterSpacing:1}}>{dataStatus}</div>
              <div style={{color:C.mut,fontSize:8,marginTop:1}}>{liveCount}/{ALL_TICKERS.length} LIVE FEEDS</div>
              <div style={{display:"flex",gap:3,marginTop:3,justifyContent:"center"}}>
                {ALL_TICKERS.map(t=><div key={t} style={{width:5,height:5,borderRadius:"50%",background:prices[t]?.source==="LIVE"?C.acc:C.gld,title:t}}/>)}
              </div>
            </div>
            <div style={{textAlign:"center"}}>
              <div style={{color:C.acc,fontSize:17,letterSpacing:2}}>{clk.toLocaleTimeString()}</div>
              <div style={{color:C.mut,fontSize:8}}>{clk.toLocaleDateString("en-US",{weekday:"short",month:"short",day:"numeric",year:"numeric"})}</div>
            </div>
            <div style={{display:"flex",flexDirection:"column",gap:2,fontSize:8}}>
              <span style={{color:C.acc}}>● LIVE &nbsp; SEC:{secSc.toFixed(1)}%</span>
              <span style={{color:C.mut}}>LAT {net.lat}ms · NODES {net.nd}/7</span>
              <span style={{color:C.mut}}>Binance WS · Yahoo Finance</span>
            </div>
          </div>
        </div>

        {/* ─── TICKER STRIP ─── */}
        <div style={{display:"flex",gap:6,overflowX:"auto",marginBottom:10,paddingBottom:2}}>
          {ALL_TICKERS.map(t=>{
            const p=prices[t], up=p.chg>=0;
            return <div key={t} onClick={()=>{setMcT(t);setTab("montecarlo");}} style={{background:C.pan,border:`1px solid ${up?C.acc+"20":C.red+"20"}`,borderRadius:4,padding:"5px 8px",minWidth:122,flexShrink:0,cursor:"pointer"}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:1}}>
                <span style={{color:C.mut,fontSize:8}}>{t}</span>
                <SourceBadge src={p.source}/>
              </div>
              <div style={{color:up?C.acc:C.red,fontSize:13,fontWeight:700}}>{fmtP(p.price)}</div>
              <div style={{display:"flex",alignItems:"center",justifyContent:"space-between"}}>
                <span style={{color:up?`${C.acc}80`:`${C.red}80`,fontSize:8}}>{up?"▲":"▼"}{Math.abs(p.chg).toFixed(2)}%</span>
                <Spark data={p.hist} color={up?C.acc:C.red} w={44} h={16}/>
              </div>
            </div>;
          })}
        </div>

        {/* ─── TABS ─── */}
        <div style={{display:"flex",gap:1,marginBottom:12,borderBottom:`1px solid ${C.bdr}`,overflowX:"auto"}}>
          {TABS.map(tb=><button key={tb.id} onClick={()=>setTab(tb.id)} style={{background:tab===tb.id?`${C.acc}10`:"transparent",border:"none",borderBottom:tab===tb.id?`2px solid ${C.acc}`:"2px solid transparent",color:tab===tb.id?C.acc:C.mut,padding:"6px 12px",fontSize:9,letterSpacing:2,cursor:"pointer",whiteSpace:"nowrap",transition:"all .15s"}}>{tb.lb}</button>)}
        </div>

        {/* ══ DASHBOARD ══ */}
        {tab==="dashboard"&&(
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:10}}>
            {/* Agents */}
            <div style={{background:C.pan,border:`1px solid ${C.bdr}`,borderRadius:6,padding:12}}>
              <Lbl t="Agent Network"/>
              {AGENTS.map(a=>{
                const st=agSt[a.id];
                const sc={EXECUTING:C.gld,ANALYZING:C.pur,SCANNING:C.blu,MONITORING:C.acc,IDLE:C.mut}[st.status]||C.mut;
                return <div key={a.id} onClick={()=>{setSelAg(a);setTab("agents");}} style={{display:"flex",alignItems:"center",gap:7,marginBottom:5,padding:"6px 8px",background:"#030810",borderRadius:4,border:`1px solid ${a.color}12`,cursor:"pointer"}}>
                  <div style={{color:a.color,fontSize:15,width:18,textAlign:"center"}}>{a.icon}</div>
                  <div style={{flex:1}}>
                    <div style={{display:"flex",justifyContent:"space-between"}}>
                      <span style={{color:a.color,fontSize:10,fontWeight:700}}>{a.name}</span>
                      <span style={{color:sc,fontSize:8}}>{st.status}</span>
                    </div>
                    <div style={{color:"#1E3040",fontSize:8}}>{a.role}</div>
                  </div>
                  <div style={{textAlign:"right"}}>
                    <div style={{color:st.sig?.includes("BUY")?C.acc:st.sig?.includes("SELL")?C.red:"#5A7080",fontSize:8}}>{st.sig}</div>
                    <div style={{color:C.mut,fontSize:8}}>{st.conf}%</div>
                  </div>
                </div>;
              })}
            </div>

            {/* Consensus + summary */}
            <div style={{background:C.pan,border:`1px solid ${C.bdr}`,borderRadius:6,padding:12}}>
              <Lbl t="Consensus Engine"/>
              {ALL_TICKERS.slice(0,4).map(tk=>{
                const vs=AGENTS.map(a=>votes[a.id]||"HOLD");
                const b=vs.filter(v=>v==="BUY").length,s=vs.filter(v=>v==="SELL").length,h=vs.filter(v=>v==="HOLD").length;
                const vd=b>s&&b>h?"LONG":s>b&&s>h?"SHORT":"NEUTRAL";
                const vc=vd==="LONG"?C.acc:vd==="SHORT"?C.red:C.gld;
                return <div key={tk} style={{marginBottom:7,padding:"6px 8px",background:"#030810",borderRadius:4,border:`1px solid ${vc}10`}}>
                  <div style={{display:"flex",justifyContent:"space-between",marginBottom:3}}>
                    <span style={{color:"#90A8B4",fontSize:10}}>{tk}</span>
                    <div style={{display:"flex",gap:5,alignItems:"center"}}>
                      <span style={{color:"#5A7080",fontSize:9}}>{fmtP(prices[tk]?.price||0)}</span>
                      <span style={{color:vc,fontSize:8,fontWeight:700}}>{vd}</span>
                    </div>
                  </div>
                  <div style={{display:"flex",gap:2}}>
                    {[...Array(b)].map((_,i)=><div key={i} style={{flex:1,height:3,background:C.acc,borderRadius:1}}/>)}
                    {[...Array(h)].map((_,i)=><div key={i} style={{flex:1,height:3,background:C.gld,borderRadius:1}}/>)}
                    {[...Array(s)].map((_,i)=><div key={i} style={{flex:1,height:3,background:C.red,borderRadius:1}}/>)}
                  </div>
                </div>;
              })}
              <div style={{marginTop:7,padding:"8px",background:"#030810",borderRadius:4,border:`1px solid ${C.acc}15`}}>
                <div style={{display:"flex",justifyContent:"space-between",marginBottom:3}}>
                  <span style={{color:C.mut,fontSize:8}}>TOTAL VALUE</span>
                  <span style={{color:C.acc,fontSize:14,fontWeight:700}}>${totVal.toLocaleString("en-US",{minimumFractionDigits:2,maximumFractionDigits:2})}</span>
                </div>
                <div style={{display:"flex",justifyContent:"space-between"}}>
                  <span style={{color:C.mut,fontSize:8}}>DAILY P&L</span>
                  <span style={{color:pnlPct>=0?C.acc:C.red,fontSize:10}}>{pnlPct>=0?"+":""}{pnlPct.toFixed(2)}%</span>
                </div>
              </div>
            </div>

            {/* News */}
            <div style={{background:C.pan,border:`1px solid ${C.bdr}`,borderRadius:6,padding:12,gridRow:"span 2"}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:7}}>
                <Lbl t="Global Live News"/>
                <select value={nFilt} onChange={e=>setNFilt(e.target.value)} style={{background:"#030810",border:`1px solid ${C.bdr}`,color:C.mut,fontSize:8,padding:"2px 4px",borderRadius:3,cursor:"pointer",marginBottom:8}}>
                  {["ALL","MACRO","CRYPTO","EQUITY","FOREX","COMMOD","QUANT"].map(f=><option key={f}>{f}</option>)}
                </select>
              </div>
              <div style={{height:510,overflowY:"auto",scrollbarWidth:"none"}}>
                {fNews.map((n,i)=>{
                  const sc={POS:C.acc,NEG:C.red,NEU:C.gld}[n.sent]||C.mut;
                  const tc={MACRO:C.blu,CRYPTO:C.acc,EQUITY:C.gld,FOREX:C.pur,COMMOD:"#FF8C42",QUANT:C.pur}[n.tag]||C.mut;
                  return <div key={i} style={{marginBottom:7,padding:"7px 8px",background:"#030810",borderRadius:4,border:`1px solid ${sc}12`}}>
                    <div style={{display:"flex",justifyContent:"space-between",marginBottom:2,alignItems:"center"}}>
                      <span style={{fontSize:7,color:tc,padding:"1px 4px",background:`${tc}12`,borderRadius:6}}>{n.tag}</span>
                      <div style={{display:"flex",gap:4}}>
                        <span style={{fontSize:7,color:sc}}>●{n.sent}</span>
                        <span style={{fontSize:7,color:"#0F1E28"}}>{n.age} ago</span>
                      </div>
                    </div>
                    <div style={{color:"#6A8898",fontSize:9,lineHeight:1.55}}>{n.hl}</div>
                    <div style={{color:"#0F1E28",fontSize:7,marginTop:2}}>{n.src}</div>
                  </div>;
                })}
              </div>
            </div>

            {/* Logs */}
            <div style={{background:C.pan,border:`1px solid ${C.bdr}`,borderRadius:6,padding:12,gridColumn:"span 2"}}>
              <Lbl t="System Event Log"/>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:5,height:160,overflowY:"auto",scrollbarWidth:"none"}}>
                {logs.map(l=><div key={l.id} style={{padding:"3px 6px",background:"#030810",borderRadius:3,borderLeft:`2px solid ${C.acc}25`}}>
                  <div style={{color:"#0F1E28",fontSize:7}}>{l.ts}</div>
                  <div style={{color:"#2E5545",fontSize:8,lineHeight:1.4}}>{l.msg}</div>
                </div>)}
              </div>
            </div>
          </div>
        )}

        {/* ══ AGENTS ══ */}
        {tab==="agents"&&(
          <div style={{display:"grid",gridTemplateColumns:"210px 1fr",gap:10}}>
            <div style={{display:"flex",flexDirection:"column",gap:6}}>
              {AGENTS.map(a=>{
                const st=agSt[a.id],act=selAg.id===a.id;
                return <div key={a.id} onClick={()=>{setSelAg(a);setChat([]);}} style={{padding:9,background:act?`${a.color}0C`:"#030810",border:`1px solid ${act?a.color+"40":C.bdr}`,borderRadius:5,cursor:"pointer",transition:"all .2s"}}>
                  <div style={{display:"flex",alignItems:"center",gap:6,marginBottom:2}}>
                    <span style={{color:a.color,fontSize:15}}>{a.icon}</span>
                    <span style={{color:a.color,fontSize:10,fontWeight:700}}>{a.name}</span>
                    <span style={{marginLeft:"auto",fontSize:7,color:a.color,background:`${a.color}10`,padding:"1px 4px",borderRadius:6}}>{st.conf}%</span>
                  </div>
                  <div style={{color:C.mut,fontSize:8}}>{a.role}</div>
                  <div style={{color:"#1A2A30",fontSize:7,marginTop:1,lineHeight:1.4}}>{a.spec}</div>
                  <div style={{marginTop:3,fontSize:8,color:st.sig?.includes("BUY")?C.acc:st.sig?.includes("SELL")?C.red:"#4A6070"}}>{st.sig}</div>
                </div>;
              })}
            </div>
            <div style={{background:C.pan,border:`1px solid ${C.bdr}`,borderRadius:6,padding:13,display:"flex",flexDirection:"column",minHeight:480}}>
              <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:10,paddingBottom:8,borderBottom:`1px solid ${C.bdr}`}}>
                <span style={{color:selAg.color,fontSize:19}}>{selAg.icon}</span>
                <div>
                  <div style={{color:selAg.color,fontSize:12,fontWeight:700}}>{selAg.name} — {selAg.role}</div>
                  <div style={{color:"#1A2A30",fontSize:8}}>{selAg.spec}</div>
                </div>
                <div style={{marginLeft:"auto",display:"flex",gap:6,alignItems:"center"}}>
                  <span style={{fontSize:8,color:C.acc}}>LIVE PRICES INJECTED</span>
                  <div style={{padding:"2px 8px",background:`${selAg.color}12`,border:`1px solid ${selAg.color}35`,borderRadius:3,fontSize:8,color:selAg.color}}>ONLINE</div>
                </div>
              </div>
              <div style={{flex:1,overflowY:"auto",marginBottom:8,scrollbarWidth:"none",minHeight:260}}>
                {chat.length===0&&<div style={{color:"#0F1E28",textAlign:"center",padding:32,fontSize:10}}>Establish a secure channel with {selAg.name}.<br/><span style={{fontSize:8}}>Live market prices are automatically injected into every response.</span></div>}
                {chat.map((m,i)=><div key={i} style={{marginBottom:8,display:"flex",flexDirection:"column",alignItems:m.role==="user"?"flex-end":"flex-start"}}>
                  <div style={{fontSize:7,color:"#0F1E28",marginBottom:2}}>{m.role==="user"?"OPERATOR":selAg.name}</div>
                  <div style={{maxWidth:"80%",padding:"7px 10px",borderRadius:5,background:m.role==="user"?"#050D18":`${selAg.color}0A`,border:`1px solid ${m.role==="user"?C.bdr:selAg.color+"22"}`,color:m.role==="user"?"#4A6070":"#A0B8C4",fontSize:10,lineHeight:1.65}}>{m.content}</div>
                </div>)}
                {chatL&&<div style={{display:"flex",gap:3,padding:"6px 10px"}}>{[0,1,2].map(i=><div key={i} style={{width:4,height:4,borderRadius:"50%",background:selAg.color,animation:`pulse .9s ease-in-out ${i*.2}s infinite alternate`}}/>)}</div>}
                <div ref={chatBot}/>
              </div>
              <div style={{display:"flex",gap:6}}>
                <input value={chatIn} onChange={e=>setChatIn(e.target.value)} onKeyDown={e=>e.key==="Enter"&&doChat()} placeholder={`Query ${selAg.name} with live market context...`} style={{flex:1,background:"#030810",border:`1px solid ${selAg.color}28`,borderRadius:4,padding:"7px 10px",color:"#A0B8C4",fontSize:10,outline:"none",fontFamily:"inherit"}}/>
                <button onClick={doChat} disabled={chatL} style={{padding:"7px 14px",background:`${selAg.color}12`,border:`1px solid ${selAg.color}40`,borderRadius:4,color:selAg.color,fontSize:9,cursor:"pointer",letterSpacing:1}}>SEND ▶</button>
              </div>
            </div>
          </div>
        )}

        {/* ══ MONTE CARLO ══ */}
        {tab==="montecarlo"&&(
          <div style={{display:"grid",gridTemplateColumns:"1fr 275px",gap:10}}>
            <div style={{background:C.pan,border:`1px solid ${C.bdr}`,borderRadius:6,padding:13}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:11}}>
                <Lbl t="Quantum-Enhanced Monte Carlo — 30-Day Simulation (Real Prices)"/>
                <div style={{display:"flex",gap:6,alignItems:"center"}}>
                  <select value={mcT} onChange={e=>setMcT(e.target.value)} style={{background:"#030810",border:`1px solid ${C.bdr}`,color:C.acc,fontSize:9,padding:"3px 6px",borderRadius:3,cursor:"pointer",fontFamily:"inherit"}}>
                    {ALL_TICKERS.map(t=><option key={t}>{t}</option>)}
                  </select>
                  <SourceBadge src={prices[mcT]?.source||"SIM"}/>
                  <button onClick={doMC} disabled={mcRun} style={{padding:"3px 11px",background:`${C.acc}12`,border:`1px solid ${C.acc}40`,borderRadius:3,color:C.acc,fontSize:8,cursor:"pointer",letterSpacing:1}}>
                    {mcRun?"COMPUTING...":"↺ RERUN"}
                  </button>
                </div>
              </div>
              <div style={{marginBottom:8,padding:"5px 8px",background:"#030810",borderRadius:3,border:`1px solid ${C.bdr}`,display:"flex",gap:16,fontSize:9}}>
                <span style={{color:C.mut}}>Seed price: <span style={{color:C.acc,fontWeight:700}}>${fmtP(prices[mcT]?.price||0)}</span></span>
                <span style={{color:C.mut}}>Change: <span style={{color:prices[mcT]?.chg>=0?C.acc:C.red}}>{prices[mcT]?.chg>=0?"+":""}{(prices[mcT]?.chg||0).toFixed(3)}%</span></span>
                <span style={{color:C.mut}}>Vol/day: <span style={{color:C.gld}}>{(VOL[mcT]*100).toFixed(2)}%</span></span>
                <span style={{color:C.mut}}>Source: <span style={{color:prices[mcT]?.source==="LIVE"?C.acc:C.gld}}>{prices[mcT]?.source||"SIM"}</span></span>
              </div>
              {mcRun&&<div style={{color:C.mut,textAlign:"center",padding:48,fontSize:10}}><div style={{color:C.pur,marginBottom:5}}>◎ Running 500 quantum-enhanced stochastic paths from ${fmtP(prices[mcT]?.price||0)}...</div></div>}
              {!mcRun&&mcD&&<>
                <div style={{overflowX:"auto"}}>
                  <MCChart mc={mcD} color={C.acc} w={620} h={210}/>
                </div>
                <div style={{display:"flex",gap:5,marginTop:6,fontSize:8,color:C.mut,justifyContent:"center",flexWrap:"wrap"}}>
                  <span style={{color:`${C.acc}90`}}>━ Median</span><span style={{color:`${C.acc}50`}}>━ P25/P75</span>
                  <span style={{color:`${C.acc}22`}}>━ 500 paths</span><span style={{color:`${C.red}60`}}>━ P05</span><span style={{color:`${C.acc}60`}}>━ P95</span>
                </div>
                <div style={{marginTop:11,display:"grid",gridTemplateColumns:"1fr 1fr 1fr 1fr",gap:6}}>
                  {[
                    {lb:"Bear P15",v:`$${fmtP(mcD.bear)}`,col:C.red},
                    {lb:"Median P50",v:`$${fmtP(mcD.median)}`,col:C.acc},
                    {lb:"Bull P85",v:`$${fmtP(mcD.bull)}`,col:"#44FF90"},
                    {lb:"VaR 95%",v:`$${fmtP(mcD.var95)}`,col:C.red},
                  ].map(m=><div key={m.lb} style={{padding:"7px 8px",background:"#030810",borderRadius:4,border:`1px solid ${m.col}15`}}>
                    <div style={{color:C.mut,fontSize:7,marginBottom:2}}>{m.lb}</div>
                    <div style={{color:m.col,fontSize:12,fontWeight:700}}>{m.v}</div>
                  </div>)}
                </div>
                <div style={{marginTop:8,padding:"8px 10px",background:`${C.pur}07`,border:`1px solid ${C.pur}18`,borderRadius:4}}>
                  <div style={{color:C.pur,fontSize:8,letterSpacing:2,marginBottom:3}}>QUANTUM ANALYSIS</div>
                  <div style={{display:"flex",gap:16,fontSize:9,flexWrap:"wrap"}}>
                    {[{l:"Coherence",v:mcD.qc,col:C.pur},{l:"CVaR 95%",v:`$${fmtP(mcD.cvar95)}`,col:C.red},{l:"Paths",v:"500",col:C.blu},{l:"Horizon",v:"30 days",col:C.acc},{l:"Mix",v:"GBM 85% + Q 15%",col:C.gld}].map(r=><span key={r.l} style={{color:C.mut}}>{r.l}: <span style={{color:r.col}}>{r.v}</span></span>)}
                  </div>
                </div>
              </>}
            </div>
            <div style={{display:"flex",flexDirection:"column",gap:8}}>
              <div style={{background:C.pan,border:`1px solid ${C.bdr}`,borderRadius:6,padding:12}}>
                <Lbl t="Asset Volatility Map"/>
                {ALL_TICKERS.map(t=>{
                  const v=VOL[t]*100,p=prices[t];
                  return <div key={t} onClick={()=>setMcT(t)} style={{marginBottom:4,padding:"4px 7px",background:mcT===t?"#050F18":"#030810",border:`1px solid ${mcT===t?C.acc+"25":C.bdr}`,borderRadius:3,cursor:"pointer"}}>
                    <div style={{display:"flex",justifyContent:"space-between",marginBottom:1}}>
                      <span style={{color:"#6A8898",fontSize:9}}>{t}</span>
                      <div style={{display:"flex",gap:4,alignItems:"center"}}>
                        <span style={{color:"#3A5060",fontSize:8}}>${fmtP(p?.price||0)}</span>
                        <span style={{color:v>1?C.red:C.acc,fontSize:8}}>{v.toFixed(1)}%</span>
                        <SourceBadge src={p?.source||"SIM"}/>
                      </div>
                    </div>
                    <div style={{height:2,background:"#0A1520",borderRadius:1}}>
                      <div style={{height:"100%",width:`${Math.min(100,v*100)}%`,background:v>1?C.red:C.acc,borderRadius:1}}/>
                    </div>
                  </div>;
                })}
              </div>
              <div style={{background:C.pan,border:`1px solid ${C.bdr}`,borderRadius:6,padding:12}}>
                <Lbl t="Quantum Parameters"/>
                {[{l:"Entropy",v:"xorshift32 + cos phase"},{l:"Noise",v:"Box-Muller + Quantum"},{l:"Paths",v:"500"},{l:"Step",v:"1/252 (daily)"},{l:"Drift",v:"Risk-neutral GBM"}].map(r=><div key={r.l} style={{marginBottom:5,padding:"4px 6px",background:"#030810",borderRadius:3}}>
                  <div style={{color:"#0F1E28",fontSize:7}}>{r.l}</div>
                  <div style={{color:C.pur,fontSize:9}}>{r.v}</div>
                </div>)}
              </div>
            </div>
          </div>
        )}

        {/* ══ RAG ══ */}
        {tab==="rag"&&(
          <div style={{display:"grid",gridTemplateColumns:"1fr 240px",gap:10}}>
            <div style={{background:C.pan,border:`1px solid ${C.bdr}`,borderRadius:6,padding:13}}>
              <Lbl t="Vectorless RAG Engine — Semantic Retrieval with Live Market Context"/>
              <div style={{display:"flex",gap:6,marginBottom:11}}>
                <input value={ragQ} onChange={e=>setRagQ(e.target.value)} onKeyDown={e=>e.key==="Enter"&&doRAG()} placeholder="Query with live prices injected... e.g. 'Should I hold BTC at current levels?'" style={{flex:1,background:"#030810",border:`1px solid ${C.pur}35`,borderRadius:4,padding:"7px 10px",color:"#A0B8C4",fontSize:10,outline:"none",fontFamily:"inherit"}}/>
                <button onClick={doRAG} disabled={ragL} style={{padding:"7px 14px",background:`${C.pur}12`,border:`1px solid ${C.pur}40`,borderRadius:4,color:C.pur,fontSize:8,cursor:"pointer",letterSpacing:1,whiteSpace:"nowrap"}}>
                  {ragL?"RETRIEVING...":"RETRIEVE ◎"}
                </button>
              </div>
              {ragL&&<div style={{color:C.mut,textAlign:"center",padding:24,fontSize:10}}><div style={{color:C.pur,marginBottom:4}}>◎ Semantic retrieval with live market context...</div></div>}
              {ragR.map((r,i)=><div key={i} style={{marginBottom:8,padding:"10px",background:"#030810",borderRadius:4,border:`1px solid ${C.pur}20`}}>
                <div style={{display:"flex",justifyContent:"space-between",marginBottom:3}}>
                  <span style={{color:"#A0B8C4",fontSize:11,fontWeight:700}}>{r.title||"Document"}</span>
                  <span style={{padding:"1px 6px",background:`${C.pur}12`,border:`1px solid ${C.pur}28`,borderRadius:8,fontSize:7,color:C.pur}}>{((r.relevance||0)*100).toFixed(0)}% MATCH</span>
                </div>
                <div style={{color:"#3A5565",fontSize:9,lineHeight:1.65}}>{r.snippet||"No summary."}</div>
                <div style={{marginTop:3,fontSize:7,color:"#0F1E28"}}>CAT: {(r.category||"—").toUpperCase()} · LIVE-AUGMENTED RETRIEVAL</div>
              </div>)}
              {ragR.length===0&&!ragL&&<div style={{color:"#0A1820",textAlign:"center",padding:32,fontSize:10}}>Live market prices are automatically included in every retrieval query.</div>}
            </div>
            <div style={{background:C.pan,border:`1px solid ${C.bdr}`,borderRadius:6,padding:12}}>
              <Lbl t="Indexed Documents"/>
              {RAG_DOCS.map(d=><div key={d.id} style={{marginBottom:6,padding:"6px 7px",background:"#030810",borderRadius:4,border:`1px solid ${C.bdr}`}}>
                <div style={{color:"#A0B8C4",fontSize:9,marginBottom:2}}>{d.title}</div>
                <div style={{display:"flex",justifyContent:"space-between",fontSize:7,color:"#0F1E28"}}>
                  <span style={{color:`${C.pur}55`}}>{d.cat}</span><span>{d.tokens.toLocaleString()} tok</span><span style={{color:`${C.acc}50`}}>{(d.rel*100).toFixed(0)}%</span>
                </div>
                <div style={{marginTop:3,height:2,background:"#0A1520",borderRadius:1}}><div style={{height:"100%",width:`${d.rel*100}%`,background:C.pur,borderRadius:1}}/></div>
              </div>)}
            </div>
          </div>
        )}

        {/* ══ CYBER SUITE ══ */}
        {tab==="security"&&(
          <div style={{display:"grid",gridTemplateColumns:"230px 1fr 215px",gap:10}}>
            <div style={{background:C.pan,border:`1px solid ${C.bdr}`,borderRadius:6,padding:12}}>
              <Lbl t="Security Posture"/>
              <div style={{display:"flex",flexDirection:"column",alignItems:"center",marginBottom:11}}>
                <svg width="92" height="92" viewBox="0 0 92 92">
                  <circle cx="46" cy="46" r="38" fill="none" stroke="#0A1520" strokeWidth="8"/>
                  <circle cx="46" cy="46" r="38" fill="none" stroke={secSc>93?C.acc:secSc>80?C.gld:C.red} strokeWidth="8"
                    strokeDasharray={`${2*Math.PI*38}`} strokeDashoffset={`${2*Math.PI*38*(1-secSc/100)}`}
                    strokeLinecap="round" transform="rotate(-90 46 46)" style={{transition:"stroke-dashoffset .6s"}}/>
                  <text x="46" y="43" textAnchor="middle" fontSize="16" fontWeight="700" fill={C.acc}>{secSc.toFixed(0)}</text>
                  <text x="46" y="55" textAnchor="middle" fontSize="7" fill={C.mut}>SCORE</text>
                </svg>
              </div>
              {[{l:"Encryption",v:"AES-256-GCM"},{l:"Auth",v:"Zero-Knowledge"},{l:"Transport",v:"TLS 1.3 + mTLS"},{l:"Signatures",v:"Ed25519"},{l:"Firewall",v:"Layer 7 Active"},{l:"Rate Limiting",v:"10 req/min"},{l:"Input Sanitize",v:"Active"},{l:"CORS",v:"Strict policy"}].map(r=><div key={r.l} style={{display:"flex",justifyContent:"space-between",marginBottom:3,fontSize:9}}><span style={{color:C.mut}}>{r.l}</span><span style={{color:C.acc}}>{r.v}</span></div>)}
              <div style={{marginTop:8,display:"flex",gap:3,flexWrap:"wrap"}}>
                {Array.from({length:net.nd},(_,i)=><div key={i} style={{padding:"2px 6px",background:"#030810",border:`1px solid ${C.acc}20`,borderRadius:3,fontSize:7,color:`${C.acc}55`}}>N-{String(i+1).padStart(2,"0")} ●</div>)}
              </div>
            </div>
            <div style={{background:C.pan,border:`1px solid ${C.bdr}`,borderRadius:6,padding:12}}>
              <Lbl t="Threat Intelligence Feed — Live"/>
              <div style={{height:390,overflowY:"auto",scrollbarWidth:"none"}}>
                {threats.map(t=>{const sc={HIGH:C.red,MED:C.gld,LOW:C.blu}[t.sev]||C.mut;return <div key={t.id} style={{marginBottom:5,padding:"6px 8px",background:"#030810",borderRadius:4,border:`1px solid ${sc}12`}}><div style={{display:"flex",justifyContent:"space-between",marginBottom:2}}><span style={{color:sc,fontSize:7,padding:"1px 4px",background:`${sc}10`,borderRadius:6}}>{t.sev}</span><span style={{color:"#0F1E28",fontSize:7}}>{t.ts}</span></div><div style={{color:"#2E5545",fontSize:9,lineHeight:1.4}}>■ {t.msg}</div></div>;})}
              </div>
            </div>
            <div style={{background:C.pan,border:`1px solid ${C.bdr}`,borderRadius:6,padding:12}}>
              <Lbl t="Security Metrics"/>
              {[{l:"Threats Blocked",v:"1,247+",col:C.red},{l:"API Calls Verified",v:"38,902",col:C.acc},{l:"ZK Proofs",v:"412",col:C.pur},{l:"Multi-sig",v:"89",col:C.blu},{l:"Input Sanitized",v:"5,821",col:C.acc},{l:"Rate Limit Hits",v:"34",col:C.gld},{l:"Uptime (30d)",v:"99.98%",col:C.acc},{l:"Avg Latency",v:`${net.lat}ms`,col:C.gld},{l:"Encrypted Chnl",v:"7/7",col:C.acc},{l:"WS Streams",v:`${liveCount} LIVE`,col:liveCount>0?C.acc:C.gld}].map(m=><div key={m.l} style={{marginBottom:6,padding:"5px 6px",background:"#030810",borderRadius:3}}><div style={{color:"#0F1E28",fontSize:7,marginBottom:1}}>{m.l}</div><div style={{color:m.col,fontSize:12,fontWeight:700}}>{m.v}</div></div>)}
            </div>
          </div>
        )}

        {/* ══ PORTFOLIO ══ */}
        {tab==="portfolio"&&(
          <div style={{display:"grid",gridTemplateColumns:"1fr 270px",gap:10}}>
            <div style={{background:C.pan,border:`1px solid ${C.bdr}`,borderRadius:6,padding:13}}>
              <Lbl t="Active Positions — Live P&L"/>
              <div style={{display:"grid",gridTemplateColumns:"2fr 1fr 1fr 1fr",gap:3,marginBottom:4,padding:"2px 6px"}}>
                {["INSTRUMENT","SIZE × ENTRY","LIVE PRICE","P&L"].map(h=><div key={h} style={{color:"#0F1E28",fontSize:7,letterSpacing:1}}>{h}</div>)}
              </div>
              {port.pos.map(pos=>{
                const cur=prices[pos.ticker]?.price??pos.entry;
                const pnl=(cur-pos.entry)*pos.size,pct=((cur-pos.entry)/pos.entry*100),ok=pnl>=0;
                return <div key={pos.ticker} style={{display:"grid",gridTemplateColumns:"2fr 1fr 1fr 1fr",gap:3,padding:"9px 6px",marginBottom:3,background:"#030810",borderRadius:4,border:`1px solid ${ok?C.acc+"12":C.red+"12"}`}}>
                  <div>
                    <div style={{display:"flex",gap:4,alignItems:"center"}}>
                      <span style={{color:"#90A8B4",fontSize:11}}>{pos.ticker}</span>
                      <SourceBadge src={prices[pos.ticker]?.source||"SIM"}/>
                    </div>
                    <Spark data={prices[pos.ticker]?.hist||[]} color={ok?C.acc:C.red} w={70} h={16}/>
                  </div>
                  <div><div style={{color:"#3A5060",fontSize:9}}>×{pos.size}</div><div style={{color:"#1E3040",fontSize:9}}>${pos.entry.toFixed(0)}</div></div>
                  <div><div style={{color:ok?C.acc:C.red,fontSize:10,fontWeight:700}}>${fmtP(cur)}</div></div>
                  <div>
                    <div style={{color:ok?C.acc:C.red,fontSize:11,fontWeight:700}}>{ok?"+":""}{pnl.toFixed(0)}</div>
                    <div style={{color:ok?`${C.acc}60`:`${C.red}60`,fontSize:8}}>{pct>=0?"+":""}{pct.toFixed(2)}%</div>
                  </div>
                </div>;
              })}
              <div style={{marginTop:11,padding:10,background:"#030810",borderRadius:4,border:`1px solid ${C.acc}15`}}>
                {[{l:"Available Cash",v:`$${port.cash.toLocaleString("en-US",{minimumFractionDigits:2,maximumFractionDigits:2})}`,col:"#90A8B4",fs:12},{l:"Total Portfolio Value",v:`$${totVal.toLocaleString("en-US",{minimumFractionDigits:2,maximumFractionDigits:2})}`,col:C.acc,fs:15},{l:"Daily P&L",v:`${pnlPct>=0?"+":""}${pnlPct.toFixed(3)}%`,col:pnlPct>=0?C.acc:C.red,fs:12}].map(r=><div key={r.l} style={{display:"flex",justifyContent:"space-between",marginBottom:5}}><span style={{color:C.mut,fontSize:8}}>{r.l}</span><span style={{color:r.col,fontSize:r.fs,fontWeight:r.fs>13?700:400}}>{r.v}</span></div>)}
              </div>
            </div>
            <div style={{display:"flex",flexDirection:"column",gap:8}}>
              <div style={{background:C.pan,border:`1px solid ${C.bdr}`,borderRadius:6,padding:12}}>
                <Lbl t="Risk Metrics"/>
                {[{l:"VaR 95%",v:"$4,218",bar:0.32},{l:"Sharpe Ratio",v:"2.14",bar:0.71},{l:"Max Drawdown",v:"-3.8%",bar:0.22},{l:"Beta (SPY)",v:"0.87",bar:0.58},{l:"Sortino",v:"3.02",bar:0.80}].map(m=><div key={m.l} style={{marginBottom:7}}><div style={{display:"flex",justifyContent:"space-between",marginBottom:1}}><span style={{color:C.mut,fontSize:8}}>{m.l}</span><span style={{color:"#90A8B4",fontSize:8}}>{m.v}</span></div><div style={{height:2,background:"#0A1520",borderRadius:1}}><div style={{height:"100%",width:`${m.bar*100}%`,background:C.acc,borderRadius:1}}/></div></div>)}
              </div>
              <div style={{background:C.pan,border:`1px solid ${C.red}20`,borderRadius:6,padding:12}}>
                <Lbl t="⬡ OMEGA Risk Override"/>
                <div style={{color:"#2E4848",fontSize:9,lineHeight:1.65,marginBottom:7}}>Max single exposure 15%. VaR within bounds.</div>
                <div style={{display:"flex",gap:5,marginBottom:8}}><div style={{flex:1,padding:"4px",background:`${C.red}0C`,border:`1px solid ${C.red}20`,borderRadius:3,textAlign:"center",fontSize:8,color:`${C.red}65`}}>STOP LOSS</div><div style={{flex:1,padding:"4px",background:`${C.acc}0C`,border:`1px solid ${C.acc}20`,borderRadius:3,textAlign:"center",fontSize:8,color:`${C.acc}65`}}>HEDGED</div></div>
                <button onClick={()=>setTab("withdraw")} style={{width:"100%",padding:"8px",background:`${C.gld}0E`,border:`1px solid ${C.gld}35`,borderRadius:4,color:C.gld,fontSize:9,cursor:"pointer",fontFamily:"inherit",letterSpacing:2}}>WITHDRAW FUNDS ▶</button>
              </div>
            </div>
          </div>
        )}

        {/* ══ MERCURY ══ */}
        {tab==="mercury"&&(
          <div style={{display:"grid",gridTemplateColumns:"1fr 300px",gap:10}}>
            <div style={{background:C.pan,border:`1px solid ${C.bdr}`,borderRadius:6,padding:14}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12}}>
                <Lbl t="Mercury Bank — Live Account Data"/>
                <button onClick={loadMercury} disabled={mercuryLoading} style={{padding:"5px 14px",background:`${C.acc}12`,border:`1px solid ${C.acc}40`,borderRadius:3,color:C.acc,fontSize:9,cursor:"pointer",letterSpacing:1}}>
                  {mercuryLoading?"CONNECTING...":"LOAD MERCURY DATA ▶"}
                </button>
              </div>
              {mercuryError&&<div style={{marginBottom:10,padding:"8px 10px",background:`${C.red}0E`,border:`1px solid ${C.red}28`,borderRadius:4,color:C.red,fontSize:10,lineHeight:1.5}}>{mercuryError}</div>}
              {!mercuryAccounts&&!mercuryLoading&&!mercuryError&&<div style={{color:"#0A1820",textAlign:"center",padding:50,fontSize:11}}>
                <div style={{fontSize:20,marginBottom:8}}>🏦</div>
                <div style={{color:C.mut,marginBottom:4}}>Mercury MCP Connected</div>
                <div style={{fontSize:9}}>Click "Load Mercury Data" to fetch your live account balances, transactions, and recipient data.</div>
              </div>}
              {mercuryLoading&&<div style={{color:C.mut,textAlign:"center",padding:40,fontSize:10}}>
                <div style={{color:C.acc,marginBottom:6}}>◎ Connecting to Mercury MCP server...</div>
                <div style={{fontSize:8}}>Authenticating via OAuth · Fetching account data</div>
              </div>}
              {mercuryAccounts&&<div>
                <div style={{color:C.acc,fontSize:10,letterSpacing:2,marginBottom:10}}>ACCOUNTS</div>
                {(Array.isArray(mercuryAccounts)?mercuryAccounts:mercuryAccounts?.accounts??[]).map((acct,i)=><div key={i} style={{marginBottom:8,padding:"11px",background:"#030810",borderRadius:4,border:`1px solid ${C.acc}20`}}>
                  <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}>
                    <span style={{color:"#90A8B4",fontSize:12}}>{acct.name||acct.accountType||`Account ${i+1}`}</span>
                    <span style={{color:C.acc,fontSize:16,fontWeight:700}}>${(acct.availableBalance??acct.currentBalance??0).toLocaleString("en-US",{minimumFractionDigits:2,maximumFractionDigits:2})}</span>
                  </div>
                  <div style={{display:"flex",gap:12,fontSize:9,color:C.mut}}>
                    {acct.accountNumber&&<span>···{String(acct.accountNumber).slice(-4)}</span>}
                    {acct.routingNumber&&<span>Routing: ···{String(acct.routingNumber).slice(-4)}</span>}
                    {acct.kind&&<span style={{color:`${C.acc}70`}}>{acct.kind}</span>}
                    {acct.status&&<span style={{color:acct.status==="active"?C.acc:C.gld}}>{acct.status}</span>}
                  </div>
                </div>)}
                {mercuryTxns&&<div style={{marginTop:12}}>
                  <div style={{color:C.acc,fontSize:10,letterSpacing:2,marginBottom:8}}>RECENT TRANSACTIONS</div>
                  {(Array.isArray(mercuryTxns)?mercuryTxns:mercuryTxns?.transactions??[]).slice(0,8).map((tx,i)=><div key={i} style={{display:"flex",justifyContent:"space-between",marginBottom:5,padding:"6px 8px",background:"#030810",borderRadius:3,border:`1px solid ${C.bdr}`}}>
                    <div>
                      <div style={{color:"#7A9098",fontSize:9}}>{tx.counterpartyName||tx.description||"Transaction"}</div>
                      <div style={{color:"#0F1E28",fontSize:7}}>{tx.postedDate||tx.createdAt||""}</div>
                    </div>
                    <span style={{color:tx.amount>0?C.acc:C.red,fontSize:11,fontWeight:700}}>{tx.amount>0?"+":""}{tx.amount?.toLocaleString("en-US",{minimumFractionDigits:2,maximumFractionDigits:2,style:"currency",currency:"USD"})}</span>
                  </div>)}
                </div>}
              </div>}
            </div>
            <div style={{display:"flex",flexDirection:"column",gap:8}}>
              <div style={{background:C.pan,border:`1px solid ${C.bdr}`,borderRadius:6,padding:12}}>
                <Lbl t="Mercury MCP Tools"/>
                {["load_accounts_card","load_account","load_transaction","load_recipient","load_account_statement"].map(tool=><div key={tool} style={{marginBottom:5,padding:"5px 7px",background:"#030810",borderRadius:3,border:`1px solid ${C.bdr}`}}>
                  <div style={{color:C.acc,fontSize:8}}>{tool}</div>
                  <div style={{color:"#1A2A30",fontSize:7}}>Mercury banking API</div>
                </div>)}
              </div>
              <div style={{background:C.pan,border:`1px solid ${C.bdr}`,borderRadius:6,padding:12}}>
                <Lbl t="Integration Status"/>
                {[{l:"MCP Server",v:"mercury.com",col:C.acc},{l:"Auth",v:"OAuth 2.0",col:C.acc},{l:"Encryption",v:"TLS 1.3",col:C.acc},{l:"Data",v:"Read-only",col:C.gld},{l:"Withdrawal",v:"Multi-sig",col:C.acc}].map(r=><div key={r.l} style={{display:"flex",justifyContent:"space-between",marginBottom:5,fontSize:9}}><span style={{color:C.mut}}>{r.l}</span><span style={{color:r.col}}>{r.v}</span></div>)}
              </div>
            </div>
          </div>
        )}

        {/* ══ WITHDRAWAL ══ */}
        {tab==="withdraw"&&(
          <div style={{display:"grid",gridTemplateColumns:"1fr 295px",gap:10}}>
            <div style={{background:C.pan,border:`1px solid ${C.bdr}`,borderRadius:6,padding:15}}>
              <Lbl t="Secure Withdrawal — ZK-Authenticated · Rate-Limited · Input-Validated"/>
              <div style={{display:"flex",alignItems:"center",marginBottom:16,gap:0}}>
                {["Amount","Confirm","2FA","Done"].map((s,i)=>{
                  const n=i+1,act=wdStep===n,dn=wdStep>n;
                  return <div key={s} style={{display:"flex",alignItems:"center",flex:1}}>
                    <div style={{display:"flex",flexDirection:"column",alignItems:"center",gap:2}}>
                      <div style={{width:22,height:22,borderRadius:"50%",background:dn?C.acc:act?`${C.gld}20`:"#0A1520",border:`1px solid ${dn?C.acc:act?C.gld:C.bdr}`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:8,color:dn?"#020408":act?C.gld:C.mut}}>{dn?"✓":n}</div>
                      <div style={{fontSize:7,color:act?C.gld:dn?C.acc:C.mut}}>{s}</div>
                    </div>
                    {i<3&&<div style={{flex:1,height:1,background:dn?C.acc:C.bdr,margin:"0 2px",marginBottom:10}}/>}
                  </div>;
                })}
              </div>
              {wdStep===1&&<div>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:9,marginBottom:11}}>
                  <div><div style={{color:C.mut,fontSize:8,marginBottom:3}}>ASSET</div>
                    <select value={wdAsset} onChange={e=>setWdAsset(e.target.value)} style={{width:"100%",background:"#030810",border:`1px solid ${C.bdr}`,color:"#90A8B4",fontSize:10,padding:"7px 8px",borderRadius:4,fontFamily:"inherit",cursor:"pointer"}}>
                      {["USDT","BTC","ETH","USDC"].map(a=><option key={a}>{a}</option>)}
                    </select></div>
                  <div><div style={{color:C.mut,fontSize:8,marginBottom:3}}>AMOUNT</div>
                    <input type="number" min="0" step="any" value={wdAmt} onChange={e=>setWdAmt(e.target.value)} placeholder="0.00" style={{width:"100%",background:"#030810",border:`1px solid ${C.bdr}`,color:"#90A8B4",fontSize:12,padding:"7px 8px",borderRadius:4,fontFamily:"inherit",outline:"none"}}/></div>
                </div>
                <div style={{marginBottom:11}}><div style={{color:C.mut,fontSize:8,marginBottom:3}}>DESTINATION ADDRESS</div>
                  <input value={wdAddr} onChange={e=>setWdAddr(e.target.value)} placeholder="0x... or bc1q..." style={{width:"100%",background:"#030810",border:`1px solid ${C.bdr}`,color:"#90A8B4",fontSize:10,padding:"7px 8px",borderRadius:4,fontFamily:"inherit",outline:"none"}}/></div>
                <div style={{marginBottom:11,padding:"7px 8px",background:"#030810",borderRadius:4,border:`1px solid ${C.bdr}`,fontSize:9,color:C.mut}}>
                  Available: <span style={{color:C.acc}}>${port.cash.toFixed(2)}</span>
                  {mercuryAccounts&&<span style={{color:C.acc}}> · Mercury: ${((Array.isArray(mercuryAccounts)?mercuryAccounts:mercuryAccounts?.accounts??[])[0]?.availableBalance??0).toLocaleString("en-US",{minimumFractionDigits:2})}</span>}
                  &nbsp;· Fee: <span style={{color:C.gld}}>~$2.40</span>
                </div>
                {wdErr&&<div style={{marginBottom:8,padding:"5px 8px",background:`${C.red}0C`,border:`1px solid ${C.red}25`,borderRadius:4,color:C.red,fontSize:9}}>{wdErr}</div>}
                <button onClick={()=>{const e=wdValidate();if(e){setWdErr(e);return;}setWdErr("");setWdStep(2);}} style={{width:"100%",padding:"9px",background:`${C.gld}10`,border:`1px solid ${C.gld}40`,borderRadius:4,color:C.gld,fontSize:10,cursor:"pointer",fontFamily:"inherit",letterSpacing:2}}>CONTINUE →</button>
              </div>}
              {wdStep===2&&<div>
                <div style={{padding:12,background:"#030810",borderRadius:5,border:`1px solid ${C.gld}18`,marginBottom:11}}>
                  <div style={{color:C.gld,fontSize:8,letterSpacing:2,marginBottom:8}}>REVIEW TRANSACTION</div>
                  {[{l:"Amount",v:`${sanitizeNum(wdAmt)} ${wdAsset}`},{l:"Destination",v:maskAddr(wdAddr)},{l:"Network Fee",v:"~$2.40"},{l:"Security",v:"ZK-proof + multi-sig"},{l:"ETA",v:"< 3 minutes"}].map(r=><div key={r.l} style={{display:"flex",justifyContent:"space-between",marginBottom:5,fontSize:10}}><span style={{color:C.mut}}>{r.l}</span><span style={{color:"#90A8B4"}}>{r.v}</span></div>)}
                </div>
                <div style={{display:"flex",gap:6}}>
                  <button onClick={()=>setWdStep(1)} style={{flex:1,padding:"8px",background:"#030810",border:`1px solid ${C.bdr}`,borderRadius:4,color:C.mut,fontSize:9,cursor:"pointer",fontFamily:"inherit"}}>← BACK</button>
                  <button onClick={()=>setWdStep(3)} style={{flex:2,padding:"8px",background:`${C.gld}10`,border:`1px solid ${C.gld}40`,borderRadius:4,color:C.gld,fontSize:9,cursor:"pointer",fontFamily:"inherit",letterSpacing:1}}>CONFIRM →</button>
                </div>
              </div>}
              {wdStep===3&&<div>
                <div style={{textAlign:"center",marginBottom:13}}>
                  <div style={{fontSize:28,marginBottom:4}}>🔐</div>
                  <div style={{color:"#90A8B4",fontSize:11}}>Two-Factor Authentication</div>
                  <div style={{color:C.mut,fontSize:9,marginTop:2}}>Enter your 4-digit PIN to authorize.</div>
                </div>
                <div style={{marginBottom:11,textAlign:"center"}}>
                  <input value={wdPin} onChange={e=>setWdPin(e.target.value.replace(/\D/,"").slice(0,4))} type="password" placeholder="••••" maxLength={4} style={{textAlign:"center",background:"#030810",border:`2px solid ${C.acc}35`,borderRadius:5,padding:"10px 16px",color:C.acc,fontSize:19,letterSpacing:8,outline:"none",fontFamily:"inherit",width:124}}/>
                </div>
                {wdErr&&<div style={{marginBottom:8,padding:"5px 8px",background:`${C.red}0C`,border:`1px solid ${C.red}25`,borderRadius:4,color:C.red,fontSize:9,textAlign:"center"}}>{wdErr}</div>}
                <div style={{display:"flex",gap:6}}>
                  <button onClick={()=>setWdStep(2)} style={{flex:1,padding:"8px",background:"#030810",border:`1px solid ${C.bdr}`,borderRadius:4,color:C.mut,fontSize:9,cursor:"pointer",fontFamily:"inherit"}}>← BACK</button>
                  <button onClick={()=>{
                    if(wdPin.length<4){setWdErr("Enter 4-digit PIN.");return;}
                    setWdErr("");setWdLoad(true);
                    setTimeout(()=>{
                      const amt=sanitizeNum(wdAmt);
                      setWdHist(p=>[{id:`WD-${8822+p.length}`,amt,asset:wdAsset,to:maskAddr(wdAddr),st:"CONFIRMED",ts:new Date().toLocaleString()},...p]);
                      setPort(p=>({...p,cash:Math.max(0,p.cash-amt)}));
                      setWdLoad(false);setWdStep(4);setWdAmt("");setWdAddr("");setWdPin("");
                    },1800);
                  }} disabled={wdLoad} style={{flex:2,padding:"8px",background:`${C.acc}10`,border:`1px solid ${C.acc}40`,borderRadius:4,color:C.acc,fontSize:9,cursor:"pointer",fontFamily:"inherit",letterSpacing:1}}>
                    {wdLoad?"PROCESSING...":"AUTHORIZE ✓"}
                  </button>
                </div>
              </div>}
              {wdStep===4&&<div style={{textAlign:"center",padding:26}}>
                <div style={{color:C.acc,fontSize:42,marginBottom:8}}>✓</div>
                <div style={{color:C.acc,fontSize:13,fontWeight:700,marginBottom:4,letterSpacing:2}}>WITHDRAWAL CONFIRMED</div>
                <div style={{color:C.mut,fontSize:9,lineHeight:1.7,marginBottom:12}}>ZK-proof validated · Multi-sig authorized · ETA &lt;3 min</div>
                <button onClick={()=>setWdStep(1)} style={{padding:"8px 22px",background:`${C.acc}10`,border:`1px solid ${C.acc}40`,borderRadius:4,color:C.acc,fontSize:9,cursor:"pointer",fontFamily:"inherit",letterSpacing:2}}>NEW WITHDRAWAL</button>
              </div>}
            </div>
            <div style={{background:C.pan,border:`1px solid ${C.bdr}`,borderRadius:6,padding:12}}>
              <Lbl t="Withdrawal History"/>
              {wdHist.map(w=><div key={w.id} style={{marginBottom:6,padding:"8px",background:"#030810",borderRadius:4,border:`1px solid ${C.acc}10`}}>
                <div style={{display:"flex",justifyContent:"space-between",marginBottom:2}}>
                  <span style={{color:C.mut,fontSize:8}}>{w.id}</span>
                  <span style={{color:C.acc,fontSize:7,padding:"1px 4px",background:`${C.acc}10`,borderRadius:6}}>{w.st}</span>
                </div>
                <div style={{color:"#90A8B4",fontSize:11,fontWeight:700,marginBottom:2}}>{w.amt.toLocaleString()} {w.asset}</div>
                <div style={{color:"#1E3040",fontSize:8,marginBottom:1}}>To: {w.to}</div>
                <div style={{color:"#0A1520",fontSize:7}}>{w.ts}</div>
              </div>)}
            </div>
          </div>
        )}

        {/* FOOTER */}
        <div style={{marginTop:12,paddingTop:6,borderTop:`1px solid ${C.bdr}`,display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:5}}>
          <div style={{color:"#0A1820",fontSize:7,letterSpacing:2}}>NEXUS v5.1 · BINANCE WS · YAHOO FINANCE · MERCURY MCP · NOT FINANCIAL ADVICE</div>
          <div style={{display:"flex",gap:9}}>
            {AGENTS.map(a=><div key={a.id} style={{display:"flex",alignItems:"center",gap:2}}>
              <div style={{width:4,height:4,borderRadius:"50%",background:a.color,boxShadow:`0 0 4px ${a.color}70`}}/>
              <span style={{color:"#0F1E28",fontSize:7}}>{a.name}</span>
            </div>)}
          </div>
          <div style={{color:"#0A1820",fontSize:7}}>ZK-SECURED · INPUT SANITIZED · RATE LIMITED</div>
        </div>
      </div>

      <style>{`
        @keyframes pulse{from{opacity:.15;transform:scale(.7)}to{opacity:1;transform:scale(1.1)}}
        ::-webkit-scrollbar{width:3px;height:3px}
        ::-webkit-scrollbar-track{background:#030810}
        ::-webkit-scrollbar-thumb{background:#0D1B26;border-radius:2px}
        *{box-sizing:border-box}
        input[type=number]::-webkit-inner-spin-button{-webkit-appearance:none}
        input::placeholder{color:#0F1E28}
        select option{background:#030810;color:#90A8B4}
        button:disabled{opacity:.4;cursor:not-allowed!important}
        button:not(:disabled):hover{opacity:.78}
      `}</style>
    </div>
  );
}
